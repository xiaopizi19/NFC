// ==UserScript==
// @name         【新增高速下载通道】百度云提取码破解、自动提交以及百度云限速破解 附赠百度云会员
// @namespace    bushiwoxiede
// @version      0.4.3
// @icon         https://pan.baidu.com/box-static/disk-system/images/favicon.ico
// @author       bushiwoxiede
// @description  百度云提取码破解、自动提交以及百度云限速破解；支持百度网盘、腾讯微云、蓝奏云、微博微盘、城通网盘、皮皮盘、YunFile、彩虹云、威盘和一木禾网盘。
// @match        *://pan.baidu.com/*
// @match        *://yun.baidu.com/*
// @match        *://share.weiyun.com/*
// @match        *://*.lanzous.com/*
// @match        *://vdisk.weibo.com/*
// @match        *://*.ctfile.com/*
// @match        *://*.pipipan.com/*
// @match        *://*.dfpan.com/*
// @match        *://*.ccchoo.com/*
// @match        *://*.vdisk.cn/*
// @match        *://*.yimuhe.com/*
// @match        *://*.newday.me/*
// @match        *://pan.baidu.com/disk/home*
// @match        *://yun.baidu.com/disk/home*
// @match        *://pan.baidu.com/s/*
// @match        *://yun.baidu.com/s/*
// @match        *://pan.baidu.com/share/link*
// @match        *://yun.baidu.com/share/link*
// @connect      newday.me
// @connect      ctfile.com
// @connect      pipipan.me
// @require      https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @require      https://cdn.staticfile.org/jquery/1.12.4/jquery.min.js
// @require      https://cdn.staticfile.org/snap.svg/0.5.1/snap.svg-min.js
// @require      https://cdn.staticfile.org/vue/2.6.6/vue.min.js
// @require      https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @run-at       document-idle
// @run-at       document-start
// @grant        unsafeWindow
// @grant        GM_download
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_xmlhttpRequest
// @grant        GM_openInTab
// @grant        GM_setClipboard
// ==/UserScript==

(function () {
    'use strict';

    var container = (function () {
        var obj = {
            _defines: {},
            _modules: {}
        };

        obj.define = function (name, requires, callback) {
            name = obj.processName(name);
            obj._defines[name] = {
                requires: requires,
                callback: callback
            };
        };

        obj.require = function (name, cache) {
            cache = (cache == false) ? false : true;
            name = obj.processName(name);
            if (cache && obj._modules.hasOwnProperty(name)) {
                return obj._modules[name];
            }
            else if (obj._defines.hasOwnProperty(name)) {
                var requires = obj._defines[name].requires;
                var callback = obj._defines[name].callback;

                var module = obj.use(requires, callback);
                cache && obj.register(name, module);
                return module;
            }
        };

        obj.use = function (requires, callback) {
            var module = {
                exports: {}
            };
            var params = obj.buildParams(requires, module);
            var result = callback.apply(this, params);
            if (typeof result != "undefined") {
                return result;
            }
            else {
                return module.exports;
            }
        };

        obj.register = function (name, module) {
            name = obj.processName(name);
            obj._modules[name] = module;
        };

        obj.buildParams = function (requires, module) {
            var params = [];
            requires.forEach(function (name) {
                params.push(obj.require(name));
            });
            params.push(obj.require);
            params.push(module.exports);
            params.push(module);
            return params;
        };

        obj.processName = function (name) {
            return name.toLowerCase();
        };

        return obj;
    })();

    container.define("config", [], function () {
        var obj = {
            url: location.href,
            referer: document.referrer,
            source: {
                baidu: "baidu",
                weiyun: "weiyun",
                lanzous: "lanzous"
            },
            option: {
                baidu_page_home: "baidu_page_home",
                baidu_page_share: "baidu_page_share",
                baidu_page_verify: "baidu_page_verify",
                baidu_share_status: "baidu_share_status",
                baidu_custom_password: "baidu_custom_password",
                baidu_auto_jump: "baidu_auto_jump",
                weiyun_page_verify: "weiyun_page_verify",
                weiyun_share_status: "weiyun_share_status",
                weiyun_auto_jump: "weiyun_auto_jump",
                lanzous_page_verify: "lanzous_page_verify",
                lanzous_share_status: "lanzous_share_status",
                lanzous_auto_jump: "lanzous_auto_jump",
                weibo_page_download: "weibo_page_download",
                ctfile_page_list: "ctfile_page_list",
                ctfile_page_download: "ctfile_page_download",
                yunfile_page_download: "yunfile_page_download",
                ccchoo_page_download: "ccchoo_page_download",
                ccchoo_auto_jump: "ccchoo_auto_jump",
                vdisk_page_download: "vdisk_page_download",
                yimuhe_page_download: "yimuhe_page_download",
                yimuhe_auto_jump: "yimuhe_auto_jump"
            },
            router: {
                option: "http://www.newday.me/script/option/wpzs.html"
            }
        };

        obj.getUrl = function () {
            return obj.url;
        };

        obj.setUrl = function (url) {
            obj.url = url;
        };

        obj.getReferer = function () {
            return obj.referer;
        };

        obj.setReferer = function (referer) {
            obj.referer = referer;
        };

        return obj;
    });

    container.define("util", [], function () {
        var obj = {};

        obj.parseUrlParam = function (url) {
            if (url.indexOf("?")) {
                url = url.split("?")[1];
            }
            var reg = /([^=&\s]+)[=\s]*([^=&\s]*)/g;
            var obj = {};
            while (reg.exec(url)) {
                obj[RegExp.$1] = RegExp.$2;
            }
            return obj;
        };

        obj.parseJson = function (jsonStr) {
            var jsonObject = {};
            try {
                if (jsonStr) {
                    jsonObject = JSON.parse(jsonStr);
                }
            }
            catch (e) { }
            return jsonObject;
        };

        obj.replaceVars = function (vars, value) {
            Object.keys(vars).forEach(function (key) {
                value = value.replace(key, vars[key]);
            });
            return value;
        };

        return obj;
    });

    container.define("core", ["config", "util"], function (config, util) {
        var obj = {};

        obj.getPageWindow = function () {
            return unsafeWindow;
        };

        obj.getVersion = function () {
            return GM_info.script.version;
        };

        obj.getUrlParam = function (name) {
            var param = util.parseUrlParam(config.getUrl());
            if (name) {
                return param.hasOwnProperty(name) ? param[name] : null;
            }
            else {
                return param;
            }
        };

        obj.isOptionActive = function (name) {
            var option = obj.getOption();
            return option.indexOf(name) >= 0 ? true : false;
        };

        obj.setOptionActive = function (name) {
            var option = obj.getOption();
            if (option.indexOf(name) < 0) {
                option.push(name);
                obj.setOption(option);
            }
        };

        obj.setOptionUnActive = function (name) {
            var option = obj.getOption();
            var index = option.indexOf(name);
            if (index >= 0) {
                delete option[index];
                obj.setOption(option);
            }
        };

        obj.addShareLog = function (shareId, sharePwd, shareLink, shareSource) {
            var shareLogList = obj.getShareLogList();
            shareLogList[shareId] = {
                share_id: shareId,
                share_pwd: sharePwd,
                share_link: shareLink,
                share_source: shareSource,
                share_time: (new Date()).getTime()
            };
            obj.setValue("share_log_json", JSON.stringify(shareLogList));
        };

        obj.getShareLogList = function () {
            var shareLogJson = obj.getValue("share_log_json");
            return util.parseJson(shareLogJson);
        };

        obj.ajax = function (option) {
            var details = {
                url: option.url,
                responseType: option.dataType,
                onload: function (result) {
                    option.success && option.success(result.response);
                },
                onerror: function (result) {
                    option.error && option.error(result.error);
                }
            };

            // 提交数据
            if (option.data) {
                details.method = "POST";
                if (option.data instanceof FormData) {
                    details.data = option.data;
                }
                else {
                    var formData = new FormData();
                    for (var i in option.data) {
                        formData.append(i, option.data[i]);
                    }
                    details.data = formData;
                }
            }
            else {
                details.method = "GET";
            }

            // 自定义头
            if (option.headers) {
                details.headers = option.headers;
            }

            // 超时
            if (option.timeout) {
                details.timeout = option.timeout;
            }

            GM_xmlhttpRequest(details);
        };

        obj.getConfig = function (name) {
            var configJson = obj.getValue("configJson");
            var configObject = util.parseJson(configJson);
            if (name) {
                return configObject.hasOwnProperty(name) ? configObject[name] : null;
            }
            else {
                return configObject;
            }
        };

        obj.setConfig = function (name, value) {
            var configObject = obj.getConfig();
            configObject[name] = value;
            obj.setValue("configJson", JSON.stringify(configObject));
        };

        obj.getOption = function () {
            var optionJson = obj.getValue("optionJson");
            var optionObject = util.parseJson(optionJson);

            var option = [];
            Object.values(config.option).forEach(function (value) {
                if (!(optionObject.hasOwnProperty(value) && optionObject[value] == "no")) {
                    option.push(value);
                }
            });
            return option;
        };

        obj.setOption = function (option) {
            var optionObject = {};
            Object.values(config.option).forEach(function (value) {
                if (option.indexOf(value) >= 0) {
                    optionObject[value] = "yes";
                } else {
                    optionObject[value] = "no";
                }
            });
            obj.setValue("optionJson", JSON.stringify(optionObject));
        };

        obj.getUrlParam = function (name) {
            var param = util.parseUrlParam(config.getUrl());
            if (name) {
                return param.hasOwnProperty(name) ? param[name] : null;
            }
            else {
                return param;
            }
        };

        obj.getValue = function (name) {
            return GM_getValue(name);
        };

        obj.setValue = function (name, value) {
            GM_setValue(name, value);
        };

        obj.printLog = function (data) {
            if (typeof console != "undefined") {
                console.log(data);
            }
        };

        obj.init = function (callback) {
            callback && callback();
        };

        return obj;
    });

    container.define("api", ["core", "snap"], function (core, snap) {
        var obj = {
            base: "http://api.newday.me",
        };

        obj.querySharePwd = function (shareId, shareLink, callback) {
            core.ajax({
                url: obj.base + "/share/disk/query",
                dataType: "json",
                data: {
                    share_id: shareId,
                    share_point: obj.getStrPoint(shareId),
                    share_link: shareLink,
                    share_version: core.getVersion()
                },
                success: function (response) {
                    callback && callback(response);
                },
                error: function () {
                    callback && callback("");
                }
            });
        };

        obj.storeSharePwd = function (shareId, sharePwd, shareLink, shareSource, callback) {
            // 记录日志
            core.addShareLog(shareId, sharePwd, shareLink, shareSource);

            core.ajax({
                url: obj.base + "/share/disk/store",
                dataType: "json",
                data: {
                    share_id: shareId,
                    share_pwd: sharePwd,
                    share_point: obj.getStrPoint(shareId),
                    share_link: shareLink,
                    share_version: core.getVersion()
                },
                success: function (response) {
                    callback && callback(response);
                },
                error: function () {
                    callback && callback("");
                }
            });
        };

        obj.logOption = function (option, callback) {
            core.ajax({
                url: obj.base + "/share/disk/option",
                dataType: "json",
                data: {
                    option_json: JSON.stringify(option),
                    share_version: core.getVersion()
                },
                success: function (response) {
                    callback && callback(response);
                },
                error: function () {
                    callback && callback("");
                }
            });
        };

        obj.getStrPoint = function (str) {
            if (str.length < 2) {
                return "0:0";
            }

            var path = "";
            var current, last = str[0].charCodeAt();
            var sum = last;
            for (var i = 1; i < str.length; i++) {
                current = str[i].charCodeAt();
                if (i == 1) {
                    path = path + "M";
                } else {
                    path = path + " L";
                }
                path = path + current + " " + last;
                last = current;
                sum = sum + current;
            }
            path = path + " Z";
            var index = sum % str.length;
            var data = snap.path.getPointAtLength(path, str[index].charCodeAt());
            return data.m.x + ":" + data.n.y;
        };

        return obj;
    });

    container.define("app_baidu", ["config", "core", "api", "$"], function (config, core, api, $) {
        var obj = {
            app_id: 250528,
            home_page: "https://greasyfork.org/zh-CN/scripts/378301-%E7%BD%91%E7%9B%98%E5%8A%A9%E6%89%8B",
            yun_data: null,
            size_config: {
                fileSizeLimit: 500000,
                fileSizeSmall: 500000,
                isDefaultSize: false,
                isRequestServer: true
            },
            verify_page: {
                share_pwd: null,
                setPwd: null,
                backupPwd: null,
                restorePwd: null,
                submit_pwd: null
            }
        };

        obj.run = function () {
            var url = config.getUrl();
            if (url.indexOf(".baidu.com/s/") > 0) {
                $(function () {
                    core.isOptionActive(config.option.baidu_page_share) && obj.initSharePage();
                });
                return true;
            }
            else if (url.indexOf(".baidu.com/disk/home") > 0) {
                $(function () {
                    core.isOptionActive(config.option.baidu_page_home) && obj.initHomePage();
                });
                return true;
            } else if (url.indexOf(".baidu.com/disk/timeline") > 0) {
                $(function () {
                    core.isOptionActive(config.option.baidu_page_home) && obj.initTimeLinePage();
                });
                return true;
            } else if (url.indexOf(".baidu.com/share/init") > 0) {
                $(function () {
                    core.isOptionActive(config.option.baidu_page_verify) && obj.initVerifyPage();
                });
                return true;
            }
            else {
                return false;
            }
        };

        obj.initSharePage = function () {
            obj.registerCustomAppId();

            obj.removeDownloadLimit();

            obj.removeVideoLimit();

            obj.initButtonShare();

            obj.initButtonEvent();
        };

        obj.initHomePage = function () {
            obj.registerCustomAppId();

            obj.registerCustomSharePwd();

            obj.removeDownloadLimit();

            obj.initButtonHome();

            obj.initButtonEvent();
        };

        obj.initTimeLinePage = function () {
            obj.registerCustomAppId();

            obj.registerCustomSharePwd();

            obj.removeDownloadLimit();

            obj.initButtonTimeLine();

            obj.initButtonEvent();
        };

        obj.initVerifyPage = function () {
            obj.registerStoreSharePwd();

            if (obj.initVerifyPageElement()) {
                obj.autoPaddingSharePwd();

                obj.registerPwdShareSwitch();
            }
        };

        obj.initVerifyPageElement = function () {
            var shareId = obj.getShareId();
            var $pwd = $(".input-area input");
            if (shareId && $pwd.length) {
                // 设置提取码
                obj.verify_page.setPwd = function (pwd) {
                    $pwd.val(pwd);
                };

                // 备份提取码
                obj.verify_page.backupPwd = function (pwd) {
                    $pwd.attr("data-pwd", pwd);
                };

                // 还原提取码
                obj.verify_page.restorePwd = function () {
                    $pwd.val($pwd.attr("data-pwd"));
                };

                // 提交提取码
                var $button = $(".input-area .g-button");
                if ($button.length) {
                    obj.verify_page.submit_pwd = function () {
                        $button.click();
                    };
                }

                return true;
            }
            else {
                return false;
            }
        };

        obj.autoPaddingSharePwd = function () {
            var shareId = obj.getShareId();
            var shareLink = config.getUrl();
            api.querySharePwd(shareId, shareLink, function (response) {
                if (response && response.code == 1) {
                    var sharePwd = response.data.share_pwd;
                    obj.verify_page.share_pwd = sharePwd;
                    obj.verify_page.setPwd(sharePwd);
                    obj.showTipSuccess("填充提取码成功");

                    if (core.isOptionActive(config.option.baidu_auto_jump)) {
                        obj.verify_page.submit_pwd && obj.verify_page.submit_pwd();
                    }
                }
                else {
                    obj.showTipError("暂无人分享提取码");
                }
            });
        };

        obj.registerPwdShareSwitch = function () {
            // 添加开关
            $(".pickpw dt").html(`请输入提取码：<span style="float:right">
                <input type="checkbox" checked id="nd-share-check" style="vertical-align: middle;"> 
                <a target="_blank" href="`+ config.router.option + `" title="点击查看更多脚本配置">共享提取码</a>
            </span>`);
            obj.isPwdShareOpen() || $("#nd-share-check").removeAttr("checked");

            // 开关-事件
            $("#nd-share-check").on("change", function () {
                if ($(this).is(':checked')) {
                    core.setOptionActive(config.option.baidu_share_status);
                }
                else {
                    core.setOptionUnActive(config.option.baidu_share_status);
                }
            });
        };

        obj.registerStoreSharePwd = function () {
            obj.getJquery()(document).ajaxComplete(function (event, xhr, options) {
                var requestUrl = options.url;
                if (requestUrl.indexOf("/share/verify") >= 0) {
                    var match = options.data.match(/pwd=([a-z0-9]+)/i);
                    if (!match) {
                        return core.printLog("pwd share not match");
                    }

                    // 拒绝*号
                    if (obj.verify_page.backupPwd) {
                        obj.verify_page.backupPwd(match[1]);
                        setTimeout(obj.verify_page.restorePwd, 500);
                    }

                    var response = xhr.responseJSON;
                    if (!(response && response.errno == 0)) {
                        return core.printLog("pwd share error");
                    }

                    var sharePwd = match[1];
                    if (sharePwd == obj.verify_page.share_pwd) {
                        return core.printLog("pwd share not change");
                    }

                    if (!obj.isPwdShareOpen()) {
                        return core.printLog("pwd share closed");
                    }

                    var shareId = obj.getShareId();
                    var shareLink = config.getUrl();
                    api.storeSharePwd(shareId, sharePwd, shareLink, config.source.baidu);
                }
            });
        };

        obj.registerCustomAppId = function () {
            obj.getJquery()(document).ajaxSend(function (event, xhr, options) {
                var requestUrl = options.url;
                if (requestUrl.indexOf("/api/download") >= 0 || requestUrl.indexOf("/api/sharedownload") >= 0) {
                    var match = requestUrl.match(/app_id=(\d+)/);
                    if (match) {
                        options.url = requestUrl.replace(match[0], "app_id=" + obj.getAppId());
                    }
                }
            });
        };

        obj.registerCustomSharePwd = function () {
            // 功能开关
            if (!core.isOptionActive(config.option.baidu_custom_password)) {
                return;
            }

            // 生成提取码
            obj.async("function-widget-1:share/util/shareFriend/createLinkShare.js", function (shareLink) {
                var makePrivatePassword = shareLink.prototype.makePrivatePassword;
                shareLink.prototype.makePrivatePassword = function () {
                    var sharePwd = core.getConfig("share_pwd");
                    return sharePwd ? sharePwd : makePrivatePassword();
                };
            });

            // 分享事件
            obj.async("function-widget-1:share/util/shareDialog.js", function (shareDialog) {
                var onVisibilityChange = shareDialog.prototype.onVisibilityChange;
                shareDialog.prototype.onVisibilityChange = function (status) {
                    if (status && !$(".nd-input-share-pwd").length) {
                        var sharePwd = core.getConfig("share_pwd");
                        var html = `<tr>
                            <td class="first-child">
                                <label>提取码</label>
                            </td>
                            <td>
                                <input type="text" class="nd-input-share-pwd" value="`+ (sharePwd ? sharePwd : "") + `" placeholder="为空则随机四位" style="padding: 6px; width: 100px;border: 1px solid #e9e9e9;">
                            </td>
                        </tr>`;
                        $("#share .dialog-body table").append(html);
                    }
                    onVisibilityChange.call(status);
                };
            });

            // 提取码更改事件
            $(document).on("change", ".nd-input-share-pwd", function () {
                var value = this.value;
                if (value && !value.match(/^[0-9a-z]{4}$/i)) {
                    obj.showTipError("提取码只能是四位数字或字母");
                }
                core.setConfig("share_pwd", value);
            });
        };

        obj.removeDownloadLimit = function () {
            obj.async("function-widget-1:download/config.js", function (config) {
                config.sizeConfig = obj.size_config;
            });
        };

        obj.removeVideoLimit = function () {
            var message = obj.getSystemContext().message;
            if (message) {
                message.trigger("share-video-after-transfer");
            }
            else {
                core.printLog("wait removeVideoLimit...");
                obj.setTimeout(obj.removeVideoLimit, 500);
            }
        };

        obj.initButtonShare = function () {
            if ($(".x-button-box").length) {
                var html = `<a class="g-button nd-button-build">
                    <span class="g-button-right">
                        <em class="icon icon-disk" title="下载"></em>
                        <span class="text">生成链接</span>
                    </span>
                </a>`;
                $(".x-button-box").append(html);
            }
            else {
                core.printLog("wait initButtonShare...");
                setTimeout(obj.initButtonShare, 500);
            }
        };

        obj.initButtonHome = function () {
            var listTools = obj.getSystemContext().Broker.getButtonBroker("listTools");
            if (listTools && listTools.$box) {
                var html = `<a class="g-button nd-button-build">
                    <span class="g-button-right">
                        <em class="icon icon-disk" title="下载"></em>
                        <span class="text">生成链接</span>
                    </span>
                </a>`;
                $(listTools.$box).prepend(html);
            }
            else {
                core.printLog("wait initButtonHome...");
                setTimeout(obj.initButtonHome, 500);
            }
        };

        obj.initButtonTimeLine = function () {
            if ($(".module-operateBtn .group-button").length) {
                var html = `<span class="button">
                    <a class="g-v-button g-v-button-middle nd-button-build">
                        <span class="g-v-button-right">
                            <em class="icon icon-disk"></em>
                            <span class="text">生成链接</span>
                        </span>
                    </a>
                </span> `;
                $(".module-operateBtn .group-button").prepend(html);
            }
            else {
                core.printLog("wait initButtonTimeLine...");
                setTimeout(obj.initButtonTimeLine, 500);
            }
        };

        obj.initButtonEvent = function () {
            // 生成链接
            $(document).on("click", ".nd-button-build", function () {
                var yunData = obj.getYunData();
                if (yunData.MYUK) {
                    var fileList = obj.getSelectedFileList();
                    var fileStat = obj.getFileListStat(fileList);
                    if (fileList.length) {
                        if (fileList.length > 1 && fileStat.file_num) {
                            obj.showDownloadSelect(fileList, fileStat);
                        }
                        else {
                            var pack = fileStat.file_num ? false : true;
                            if (obj.isHomePage()) {
                                obj.showDownloadInfoHome(fileList, pack);
                            }
                            else {
                                obj.showDownloadInfoShare(fileList, pack);
                            }
                        }
                    }
                    else {
                        obj.showTipError("请至少选择一个文件或文件夹");
                    }
                }
                else {
                    obj.showLogin();
                }
            });

            // 压缩包
            $(document).on("click", ".nd-button-pack", function () {
                var fileList = obj.getSelectedFileList();
                if (obj.isHomePage()) {
                    obj.showDownloadInfoHome(fileList, true);
                }
                else {
                    obj.showDownloadInfoShare(fileList, true);
                }
            });

            // 多文件
            $(document).on("click", ".nd-button-multi", function () {
                var fileList = obj.getSelectedFileList();

                // 过滤文件夹
                fileList = obj.filterFileListDir(fileList);

                if (obj.isHomePage()) {
                    obj.showDownloadInfoHome(fileList, false);
                }
                else {
                    obj.showDownloadInfoShare(fileList, false);
                }
            });

            // 应用ID
            $(document).on("click", ".nd-change-app-id", function () {
                obj.showAppIdChange();
            });
            $(document).on("change", ".nd-input-app-id", function () {
                obj.setAppId(this.value);
            });
        };

        obj.showLogin = function () {
            obj.getJquery()("[node-type='header-login-btn']").click();
        };

        obj.showDownloadInfoShare = function (fileList, pack) {
            obj.getDownloadShare(fileList, pack, function (response) {
                obj.hideTip();

                if (response.list && response.list.length) {
                    // 文件
                    obj.showDownloadLinkFile(response.list);
                }
                else if (response.dlink) {
                    // 压缩包
                    obj.showDownloadLinkPack(fileList, {
                        dlink: response.dlink
                    });
                }
                else {
                    // 其他
                    obj.showDialogUnKnownResponse(response);
                }
            });
        };

        obj.showDownloadInfoHome = function (fileList, pack) {
            obj.getDownloadHome(fileList, pack, function (response) {
                obj.hideTip();

                if (response.dlink && typeof response.dlink == "object" && response.dlink.length) {
                    // 文件
                    response.dlink.forEach(function (item, index) {
                        var itemOrigin = fileList[index];
                        itemOrigin.dlink = item.dlink;
                        itemOrigin.dlink_api = obj.buildDownloadUrl(itemOrigin.path);
                    });
                    obj.showDownloadLinkFile(fileList);
                }
                else if (response.dlink && typeof response.dlink == "string") {
                    // 压缩包
                    obj.showDownloadLinkPack(fileList, {
                        dlink: response.dlink
                    });
                }
                else {
                    // 其他
                    obj.showDialogUnKnownResponse(response);
                }
            });
        };

        obj.showDownloadLinkFile = function (fileList) {
            var title = "文件下载";
            var body = '<div style="padding: 20px 20px;min-height: 120px; max-height: 300px; overflow-y: auto; ">';
            fileList.forEach(function (item, index) {
                body += `<div style="margin-bottom: 10px;">`;

                body += `<div>` + (index + 1) + `：` + item.server_filename + `</div>`;

                body += `<div><a href="` + item.dlink + `" title="` + item.dlink + `" style="display:block; overflow:hidden; white-space:nowrap; text-overflow:ellipsis;">
                    [官方] `+ item.dlink + `
                </a></div>`;

                if (item.dlink_api) {
                    body += `<div><a href="` + item.dlink_api + `" title="` + item.dlink_api + `" style="display:block; overflow:hidden; white-space:nowrap; text-overflow:ellipsis;">
                        [接口] `+ item.dlink_api + `
                    </a></div>`;
                }

                body += `</div>`;
            });
            body += '</div>';
            var footer = obj.renderFooterAppId();
            obj.showDialog(title, body, footer);
        };

        obj.showDownloadLinkPack = function (fileList, data) {
            var title = "文件下载";
            var body = '<div style="padding: 20px 20px;min-height: 120px; max-height: 300px; overflow-y: auto; ">';

            var packName = obj.getDownloadPackName(fileList);
            body += `<div>` + packName + `</div>
            <div><a href="`+ data.dlink + `" title="` + data.dlink + `" style="display:block; overflow:hidden; white-space:nowrap; text-overflow:ellipsis;">
                [官方] `+ data.dlink + `
            </a></div>`;

            body += `<div style="margin-top: 15px;">打包的文件/文件夹列表</div>`;
            fileList.forEach(function (item, index) {
                body += `<div title="` + item.path + `" style="color: ` + (item.isdir ? "blue" : "inherit") + `;">[` + (index + 1) + `] ` + item.server_filename + `</div>`;
            });

            body += '</div>';
            var footer = obj.renderFooterAppId();
            obj.showDialog(title, body, footer);
        };

        obj.getDownloadPackName = function (fileList) {
            return fileList[0].server_filename + " 等" + fileList.length + "个文件.zip";
        };

        obj.buildDownloadUrl = function (path) {
            return "https://pcs.baidu.com/rest/2.0/pcs/file?method=download&app_id=" + obj.getAppId() + "&path=" + encodeURIComponent(path);
        };

        obj.showDownloadSelect = function (fileList, fileStat) {
            var title = "链接类型";
            var body = `<div style="padding: 40px 20px; max-height: 300px; overflow-y: auto;">`;

            body += `<div class="normalBtnBox g-center">
                <a class="g-button g-button-large g-button-gray-large nd-button-pack">
                    <span class="g-button-right">
                        <em class="icon icon-download"></em> 压缩包
                    </span>
                </a>
                <a class="g-button g-button-large g-button-gray-large nd-button-multi" style="margin-left:50px;">
                    <span class="g-button-right">
                        <em class="icon icon-poly"></em> 多文件
                    </span>
                </a>
            </div>`;

            if (fileStat.dir_num) {
                body += `<div style="margin-top: 40px; padding-top: 10px; margin-bottom: -20px; border-top: 1px solid #D0DFE7;">
                <p class="g-center">选择 [多文件] 会过滤当前选中的 <span style="color: red">`+ fileStat.dir_num + `</span> 个文件夹</p>`;

                var index = 1;
                fileList.forEach(function (item) {
                    if (item.isdir) {
                        body += `<p title="` + item.path + `" style="color: blue;">[` + index + `] ` + item.server_filename + `</p>`;
                        index++;
                    }
                });
                body += `</div>`;
            }

            body += `</div>`;
            var footer = obj.renderFooterAppId();
            obj.showDialog(title, body, footer);
        };

        obj.showAppIdChange = function () {
            var title = "应用ID";
            var body = `<div style="padding: 60px 20px; max-height: 300px; overflow-y: auto;">
                <div class="g-center" style="margin-bottom: 10px;">
                    当前应用ID：<input type="text" class="nd-input-app-id" style="border: 1px solid #f2f2f2; padding: 4px 5px;" value="`+ obj.getAppId() + `">
                </div>
                <div class="g-center">
                    <p>如生成链接或者下载文件异常，请尝试修改为官方应用ID【` + obj.app_id + `】</p>
                    <p>修改应用ID可能存在未知的风险，请慎重使用，更多应用ID请查看<a target="_blank" href="` + obj.home_page + `"> 脚本主页 </a></p>
                </div>
            </div>`;
            var footer = '';
            obj.showDialog(title, body, footer);
        };

        obj.showDialogUnKnownResponse = function (response) {
            var title = "未知结果";
            var body = `<div style="padding: 20px 20px; max-height: 300px; overflow-y: auto;">
                <pre style="white-space: pre-wrap; word-wrap: break-word; word-break: break-all;">` + JSON.stringify(response, null, 4) + `</pre>
            </div>`;
            var footer = obj.renderFooterAppId();
            obj.showDialog(title, body, footer);
        };

        obj.renderFooterAppId = function () {
            return `<p style="padding-top: 10px; border-top: 1px solid #D0DFE7;">
                当前应用ID：` + obj.getAppId() + ` <a href="javascript:;" class="nd-change-app-id">修改</a>，其他设置请访问 <a target="_blank" href="` + config.router.option + `">配置页面</a>
            </p > `;
        };

        obj.showDialog = function (title, body, footer) {
            var dialog = obj.require("system-core:system/uiService/dialog/dialog.js").verify({
                title: title,
                img: "img",
                vcode: "vcode"
            });

            // 内容
            $(dialog.$dialog).find(".dialog-body").html(body);

            // 底部
            $(dialog.$dialog).find(".dialog-footer").html(footer);

            dialog.show();
        };

        obj.showTipSuccess = function (msg, hasClose, autoClose) {
            obj.showTip("success", msg, hasClose, autoClose);
        };

        obj.showTipError = function (msg, hasClose, autoClose) {
            obj.showTip("failure", msg, hasClose, autoClose);
        };

        obj.showTipLoading = function (msg, hasClose, autoClose) {
            obj.showTip("loading", msg, hasClose, autoClose);
        };

        obj.showTip = function (mode, msg, hasClose, autoClose) {
            var option = {
                mode: mode,
                msg: msg
            };

            // 关闭按钮
            if (typeof hasClose != "undefined") {
                option.hasClose = hasClose;
            }

            // 自动关闭
            if (typeof autoClose != "undefined") {
                option.autoClose = autoClose;
            }

            obj.require("system-core:system/uiService/tip/tip.js").show(option);
        };

        obj.hideTip = function () {
            obj.require("system-core:system/uiService/tip/tip.js").hide({
                hideTipsAnimationFlag: 1
            });
        };

        obj.isHomePage = function () {
            var url = config.getUrl();
            if (url.indexOf(".baidu.com/disk") > 0) {
                return true;
            }
            else {
                return false;
            }
        };

        obj.isTimelinePage = function () {
            var url = config.getUrl();
            if (url.indexOf(".baidu.com/disk/timeline") > 0) {
                return true;
            }
            else {
                return false;
            }
        };

        obj.isSharePageMulti = function () {
            var yunData = obj.getYunData();
            if (yunData.SHAREPAGETYPE == "single_file_page") {
                return false;
            }
            else {
                return true;
            }
        };

        obj.getSelectedFileList = function () {
            if (obj.isHomePage()) {
                return obj.getSelectedFileListHome();
            }
            else {
                return obj.getSelectedFileListShare();
            }
        };

        obj.getSelectedFileListHome = function () {
            if (obj.isTimelinePage()) {
                return obj.require("pan-timeline:widget/store/index.js").getters.getChoosedItemArr;
            }
            else {
                return obj.require("disk-system:widget/pageModule/list/listInit.js").getCheckedItems();
            }
        };

        obj.getSelectedFileListShare = function () {
            if (obj.isSharePageMulti()) {
                return obj.require("disk-share:widget/pageModule/list/listInit.js").getCheckedItems();
            }
            else {
                var yunData = obj.getYunData();
                return yunData.FILEINFO;
            }
        };

        obj.getFileListStat = function (fileList) {
            var fileStat = {
                file_num: 0,
                dir_num: 0
            };
            fileList.forEach(function (item) {
                if (item.isdir == 0) {
                    fileStat.file_num++;
                }
                else {
                    fileStat.dir_num++;
                }
            });
            return fileStat;
        };

        obj.filterFileListDir = function (fileList) {
            var fileListFilter = [];
            fileList.forEach(function (item) {
                if (item.isdir == 0) {
                    fileListFilter.push(item);
                }
            });
            return fileListFilter;
        };

        obj.parseFidList = function (fileList) {
            var fidList = [];
            fileList.forEach(function (item) {
                fidList.push(item.fs_id);
            });
            return fidList;
        };

        obj.getDownloadShare = function (fileList, pack, callback) {
            obj.showTipLoading("生成链接中，请稍等...");
            obj.initWidgetContext("function-widget-1:download/util/context.js");
            obj.async("function-widget-1:download/service/dlinkService.js", function (dl) {
                var yunData = obj.getYunData();
                var data = {
                    list: fileList,
                    share_uk: yunData.SHARE_UK,
                    share_id: yunData.SHARE_ID,
                    sign: yunData.SIGN,
                    timestamp: yunData.TIMESTAMP,
                    type: pack ? "batch" : "nolimit"
                };
                dl.getDlinkShare(data, callback);
            });
        };

        obj.getDownloadHome = function (fileList, pack, callback) {
            obj.showTipLoading("生成链接中，请稍等...");
            obj.initWidgetContext("function-widget-1:download/util/context.js");
            obj.async("function-widget-1:download/service/dlinkService.js", function (dl) {
                var fidList = obj.parseFidList(fileList);
                var type = pack ? "batch" : "nolimit";
                dl.getDlinkPan(JSON.stringify(fidList), type, callback);
            });
        };

        obj.getShareId = function () {
            return core.getUrlParam("surl");
        };

        obj.isPwdShareOpen = function () {
            return core.isOptionActive(config.option.baidu_share_status);
        };

        obj.getYunData = function () {
            if (!obj.yun_data) {
                obj.yun_data = core.getPageWindow().yunData;
            }
            return obj.yun_data;
        };

        obj.getAppId = function () {
            var appId = core.getConfig("app_id");
            if (appId) {
                return appId;
            }
            else {
                return obj.app_id;
            }
        };

        obj.setAppId = function (appId) {
            core.setConfig("app_id", appId);
            api.logOption({
                app_id: appId
            });
        };

        obj.initWidgetContext = function (name, callback) {
            var initFunc = function (widget) {
                if (!widget.getContext()) {
                    widget.setContext(obj.getSystemContext());
                }
                callback && callback();
            };
            if (callback) {
                obj.async(name, initFunc);
            }
            else {
                initFunc(obj.require(name));
            }
        };

        obj.ajax = function (option) {
            obj.getJquery().ajax(option);
        };

        obj.getSystemContext = function () {
            return obj.require("system-core:context/context.js").instanceForSystem;
        };

        obj.getJquery = function () {
            return obj.require("base:widget/libs/jquerypacket.js");
        };

        obj.require = function (name) {
            return core.getPageWindow().require(name);
        };

        obj.async = function (name, callback) {
            core.getPageWindow().require.async(name, callback);
        };

        return obj;
    });

    container.define("app_weiyun", ["config", "core", "api", "$"], function (config, core, api, $) {
        var obj = {
            axios: null,
            modal: null,
            store: null,
            inject_name: "_nd_inject_",
            webpack_require: null,
            verify_page: {
                setPwd: null,
                share_pwd: null,
                submit_pwd: null
            }
        };

        obj.run = function () {
            var url = config.getUrl();
            if (url.indexOf("share.weiyun.com") > 0) {
                $(function () {
                    core.isOptionActive(config.option.weiyun_page_verify) && obj.initVerifyPage();
                });
                return true;
            }
            else {
                return false;
            }
        };

        obj.initVerifyPage = function () {
            obj.initWebpackRequire(function () {
                obj.registerStoreSharePwd();
            });

            if (obj.initVerifyPageElement()) {
                obj.autoPaddingSharePwd();

                obj.registerPwdShareSwitch();
            }
        };

        obj.initVerifyPageElement = function () {
            var shareId = obj.getShareId();
            var $pwd = $(".card-inner .input-txt[type='password']");
            var $button = $(".card-inner .btn-main");
            if (shareId && $pwd.length && $button.length) {

                // 显示分享密码
                $pwd.attr("type", "text");

                // 设置分享密码
                obj.verify_page.setPwd = function (pwd) {
                    $pwd.val(pwd);
                };

                // 重造按钮
                var $itemButton = $button.parent();
                $itemButton.html($button.prop("outerHTML"));
                $button = $itemButton.find(".btn-main");

                // 按钮事件
                $button.on("click", function () {
                    obj.getStore() && obj.getStore().default.dispatch("shareInfo/loadShareInfoWithoutLogin", $pwd.val());
                });

                // 提交密码
                obj.verify_page.submit_pwd = function () {
                    $button.click();
                };

                return true;
            }
            else {
                return false;
            }
        };

        obj.initWebpackRequire = function (callback) {
            var moreModules = {};
            moreModules[obj.inject_name] = function (module, exports, __webpack_require__) {
                obj.webpack_require = __webpack_require__;
                callback && callback();
            };
            core.getPageWindow().webpackJsonp([obj.inject_name], moreModules, [obj.inject_name]);
        };

        obj.autoPaddingSharePwd = function () {
            var shareId = obj.getShareId();
            var shareLink = obj.getShareLink();
            api.querySharePwd(shareId, shareLink, function (response) {
                if (response && response.code == 1) {
                    var sharePwd = response.data.share_pwd;
                    obj.verify_page.share_pwd = sharePwd;
                    obj.verify_page.setPwd(sharePwd);
                    obj.showTipSuccess("填充密码成功");

                    if (core.isOptionActive(config.option.weiyun_auto_jump)) {
                        obj.verify_page.submit_pwd && obj.verify_page.submit_pwd();
                    }
                }
                else {
                    obj.showTipError("暂无人分享密码");
                }
            });
        };

        obj.registerPwdShareSwitch = function () {
            // 添加开关
            $(".card-inner .form-item-label .form-item-tit").html(`<span class="form-item-tit">
                请输入分享密码
                <span style="margin-left: 45px;">
                    <input type="checkbox" checked id="nd-share-check" style="vertical-align: middle;"> 
                    <a target="_blank" href="`+ config.router.option + `" title="点击查看更多脚本配置">共享密码</a>
                </span>
            </span>`);
            obj.isPwdShareOpen() || $("#nd-share-check").removeAttr("checked");

            // 开关-事件
            $("#nd-share-check").on("change", function () {
                if ($(this).is(':checked')) {
                    core.setOptionActive(config.option.weiyun_share_status);
                }
                else {
                    core.setOptionUnActive(config.option.weiyun_share_status);
                }
            });
        };

        obj.registerStoreSharePwd = function () {
            obj.addResponseInterceptor(function (request, response) {
                var requestUrl = request.responseURL;
                if (requestUrl.indexOf("weiyunShareNoLogin/WeiyunShareView") > 0) {
                    if (response.data.data.rsp_header.retcode == 0) {
                        var match = response.config.data.match(/\\"share_pwd\\":\\"([\w]+)\\"/);
                        if (!match) {
                            return core.printLog("pwd share not match");
                        }

                        var sharePwd = match[1];
                        if (sharePwd == obj.verify_page.share_pwd) {
                            return core.printLog("pwd share not change");
                        }

                        if (!obj.isPwdShareOpen()) {
                            return core.printLog("pwd share closed");
                        }

                        var shareId = obj.getShareId();
                        var shareLink = obj.getShareLink();
                        api.storeSharePwd(shareId, sharePwd, shareLink, config.source.weiyun);
                    }
                    else {
                        return core.printLog("pwd share error");
                    }
                }
            });
        };

        obj.addResponseInterceptor = function (callback) {
            var success = function (response) {
                try {
                    callback && callback(response.request, response);
                }
                catch (e) {
                    core.printLog(e);
                }
                return response;
            };
            var error = function () {
                return Promise.reject(error);
            };
            obj.getAxios() && obj.getAxios().interceptors.response.use(success, error);
        };

        obj.showTipSuccess = function (msg) {
            obj.getModal() && obj.getModal().success(msg);
        };

        obj.showTipError = function (msg) {
            obj.getModal() && obj.getModal().error(msg);
        };

        obj.getShareId = function () {
            var url = config.getUrl();
            var match = url.match(/share.weiyun.com\/([0-9a-z]+)/i);
            return match ? match[1] : null;
        };

        obj.getShareLink = function () {
            return config.getUrl();
        };

        obj.isPwdShareOpen = function () {
            return core.isOptionActive(config.option.weiyun_share_status);
        };

        obj.getAxios = function () {
            if (!obj.axios) {
                obj.axios = obj.matchWebpackModule(function (module, name) {
                    if (module && module.Axios) {
                        return module;
                    }
                });
            }
            return obj.axios;
        };

        obj.getModal = function () {
            if (!obj.modal) {
                obj.modal = obj.matchWebpackModule(function (module, name) {
                    if (module && module.confirm && module.success) {
                        return module;
                    }
                });
            }
            return obj.modal;
        };

        obj.getStore = function () {
            if (!obj.store) {
                obj.store = obj.matchWebpackModule(function (module, name) {
                    if (module && module.default && module.default._modulesNamespaceMap) {
                        return module;
                    }
                });
            }
            return obj.store;
        };

        obj.matchWebpackModule = function (matchFunc) {
            var names = Object.keys(obj.webpack_require.c);
            for (var i in names) {
                var name = names[i];
                var match = matchFunc(obj.webpack_require(name), name);
                if (match) {
                    return match;
                }
            }
        };

        return obj;
    });

    container.define("app_lanzous", ["config", "util", "core", "api", "$"], function (config, util, core, api, $) {
        var obj = {
            verify_page: {
                setPwd: null,
                share_pwd: null,
                submit_pwd: null
            }
        };

        obj.run = function () {
            var url = config.getUrl();
            if (url.indexOf("www.lanzous.com/fn") > 0) {
                $(function () {
                    core.isOptionActive(config.option.lanzous_page_verify) && obj.initVerifyPage();
                });
                return true;
            }
            else {
                return false;
            }
        };

        obj.initVerifyPage = function () {
            obj.registerStoreSharePwd();

            if (obj.initVerifyPageElement()) {
                obj.autoPaddingSharePwd();

                obj.registerPwdShareSwitch();
            }
        };

        obj.initVerifyPageElement = function () {
            var shareId = obj.getShareId();
            var $pwd = $("#pwd");
            if (shareId && $pwd.length) {

                // 设置分享密码
                obj.verify_page.setPwd = function (pwd) {
                    $pwd.val(pwd);
                };

                // 提交密码
                obj.verify_page.submit_pwd = function () {
                    $("#sub").click();
                };

                return true;
            }
            else {
                return false;
            }
        };

        obj.autoPaddingSharePwd = function () {
            var shareId = obj.getShareId();
            var shareLink = obj.getShareLink();
            api.querySharePwd(shareId, shareLink, function (response) {
                if (response && response.code == 1) {
                    var sharePwd = response.data.share_pwd;
                    obj.verify_page.share_pwd = sharePwd;
                    obj.verify_page.setPwd(sharePwd);
                    obj.showTip(1, "填充密码成功", 2000);

                    if (core.isOptionActive(config.option.lanzous_auto_jump)) {
                        obj.verify_page.submit_pwd && obj.verify_page.submit_pwd();
                    }
                }
                else {
                    obj.showTip(0, "暂无人分享密码", 2000);
                }
            });
        };

        obj.registerPwdShareSwitch = function () {
            // 添加开关
            $(".text").html(`<input type="checkbox" checked id="nd-share-check" style="vertical-align: middle;" > 
            <a style="cursor: pointer;" target="_blank" href="` + config.router.option + `" title="点击查看更多脚本配置">共享密码</a>`);
            obj.isPwdShareOpen() || $("#nd-share-check").removeAttr("checked");

            // 开关-事件
            $("#nd-share-check").on("change", function () {
                if ($(this).is(':checked')) {
                    core.setOptionActive(config.option.lanzous_share_status);
                }
                else {
                    core.setOptionUnActive(config.option.lanzous_share_status);
                }
            });
        };

        obj.registerStoreSharePwd = function () {
            core.getPageWindow().$(document).ajaxComplete(function (event, xhr, options) {
                var match = options.data.match(/p=(\w+)/);
                if (!match) {
                    return core.printLog("pwd share not match");
                }

                var sharePwd = match[1];
                if (sharePwd == obj.verify_page.share_pwd) {
                    return core.printLog("pwd share not change");
                }

                if (!obj.isPwdShareOpen()) {
                    return core.printLog("pwd share closed");
                }

                var shareId = obj.getShareId();
                var shareLink = obj.getShareLink();
                var response = util.parseJson(xhr.response);
                if (response && response.zt == 1 && sharePwd) {
                    api.storeSharePwd(shareId, sharePwd, shareLink, config.source.lanzous);
                }
                else {
                    core.printLog("pwd share error");
                }
            });
        };

        obj.showTip = function (code, msg, timeout) {
            if (code) {
                $("#info").html('<span style="color: green;">' + msg + '</span>');
            }
            else {
                $("#info").html('<span style="color: red;">' + msg + '</span>');
            }
            setTimeout(function () {
                $("#info").html("");
            }, timeout);
        };

        obj.getShareId = function () {
            return core.getUrlParam("f");
        };

        obj.getShareLink = function () {
            return top.location.href;
        };

        obj.isPwdShareOpen = function () {
            return core.isOptionActive(config.option.lanzous_share_status);
        };

        return obj;
    });

    container.define("app_weibo", ["config", "util", "core", "$"], function (config, util, core, $) {
        var obj = {};

        obj.run = function () {
            var url = config.getUrl();
            if (url.indexOf("vdisk.weibo.com") > 0) {
                core.isOptionActive(config.option.weibo_page_download) && obj.initDownloadPage();
                return true;
            }
            return false;
        };

        obj.initDownloadPage = function () {
            var pageWindow = core.getPageWindow();

            // 取消未登录弹窗
            pageWindow.define("2/widget/fileDownLayer", ["2/core"], function () {
                return {
                    init: function () { }
                };
            });

            // 请求下载链接
            pageWindow.seajs.use(["2/core"], function (http) {
                var $button = $("#download_small_btn");
                var fileInfo = util.parseJson($button.attr("data-info"));
                http.api({
                    url: "api/weipan/fileopsStatCount",
                    data: {
                        link: fileInfo.copy_ref,
                        ops: "download",
                        wpSign: pageWindow.SIGN
                    }
                }, function (response) {
                    var html = `<a style="color: red;" title="右键使用迅雷或者IDM进行下载" href="` + response.url + `"><i class="vd_pic_v2 ico_file_download">右键下载</i></a>`;
                    $button.after(html);
                    $button.hide();
                });
            });
        };

        return obj;
    });

    container.define("app_[ctfile|pipipan]", ["config", "core", "$"], function (config, core, $) {
        var obj = {
            base: "",
            _downloads: {}
        };

        obj.getBase = function () {
            return obj.base;
        };

        obj.setBase = function (base) {
            obj.base = base;
        };

        obj.run = function () {
            var url = config.getUrl();
            if (url.indexOf("ctfile.com") > 0) {
                obj.runDiskCtFile();
                return true;
            }
            else if (url.indexOf("pipipan.com") > 0) {
                obj.runDiskPiPiPan();
                return true;
            }
            else {
                return false;
            }
        };

        obj.runDiskCtFile = function () {
            obj.setBase("https://qihuanmp3.ctfile.com");

            var url = config.getUrl();
            if (url.indexOf("ctfile.com/u/") > 0) {
                obj.initAlbumPage();
            }
            else if (url.indexOf("ctfile.com/i/") > 0 || url.indexOf("ctfile.com/fs/") > 0) {
                $(function () {
                    obj.initDownloadPage();
                });
            }
        };

        obj.runDiskPiPiPan = function () {
            obj.setBase("https://www.pipipan.com");

            var url = config.getUrl();
            if (url.indexOf("pipipan.com/dir/") > 0) {
                obj.initAlbumPage();
            }
            else if (url.indexOf("pipipan.com/i/") > 0 || url.indexOf("pipipan.com/fs/") > 0) {
                $(function () {
                    obj.initDownloadPage();
                });
            }
        };

        obj.initAlbumPage = function () {
            core.isOptionActive(config.option.ctfile_page_list) && obj.initTableFile();
        };

        obj.initTableFile = function () {
            if ($("#table_files td a").not(".active").length) {
                var selector = $("#table_files td a").not(".active")[0];
                obj.queryTableFile(selector);
            }
            else {
                setTimeout(obj.initTableFile, 2000);
            }
        };

        obj.queryTableFile = function (selector) {
            var initFunc = function (timeout) {
                setTimeout(obj.initTableFile, timeout);
            };

            var $selector = $(selector);
            if ($selector.hasClass("active")) {
                initFunc(0);
                return;
            }
            else {
                $selector.addClass("active");
            }

            var url = $selector.attr("href");
            if (url.indexOf("/u/") == 0 || url.indexOf("/dir/") == 0) {
                initFunc(0);
            }
            else {
                obj.queryFileUrlPage(url, function (response) {
                    initFunc(100);

                    if (response && response.downurl) {
                        $selector.attr("href", response.downurl);
                        $selector.css("color", "red");
                        $selector.attr("title", "右键使用迅雷或者IDM进行下载");
                    }
                });
            }
        };

        obj.initDownloadPage = function () {
            // 禁用广告
            core.getPageWindow()._popup_ispoped = true;

            core.isOptionActive(config.option.ctfile_page_download) && obj.queryFileUrl(document.body.innerHTML, function (response) {
                if (response && response.downurl) {
                    var $downLink = $("#free_down_link");
                    $downLink.removeAttr("onclick");
                    $downLink.attr("href", response.downurl);
                    $downLink.find("em").css("color", "red");
                    $downLink.attr("title", "右键使用迅雷或者IDM进行下载");
                }
            });
        };

        obj.queryFileUrlPage = function (url, callback) {
            obj.pageQuery(url, function (response) {
                if (response) {
                    obj.queryFileUrl(response, callback);
                }
                else {
                    callback && callback("");
                }
            });
        };

        obj.queryFileUrl = function (html, callback) {
            var uid = obj.parseUid(html);
            var fid = obj.parseFid(html);
            var chk = obj.parseChk($(html).find("#free_down_link").attr("onclick"));
            var code = "";
            var referer = config.getUrl();
            obj.downloadQuery(uid, fid, chk, code, referer, callback);
        };

        obj.parseUid = function (html) {
            var match = html.match(/uid=(\d+)/)
            if (match) {
                return match[1];
            }
        };

        obj.parseFid = function (html) {
            var match = html.match(/fid=(\d+)/)
            if (match) {
                return match[1];
            }
        };

        obj.parseChk = function (html) {
            if (html) {
                var match = html.match(/, '(\S+)',/);
                if (match) {
                    return match[1];
                }
            }
        };

        obj.pageQuery = function (url, callback) {
            core.ajax({
                url: obj.getBase() + url,
                dataType: "text",
                success: function (response) {
                    callback && callback(response);
                },
                error: function (error) {
                    callback && callback("");
                }
            });
        };

        obj.downloadQuery = function (uid, fid, chk, code, referer, callback) {
            var key = [uid, fid, chk].join("_");
            if (obj._downloads.hasOwnProperty(key)) {
                callback && callback(obj._downloads[key]);
            }
            else {
                var url = obj.getBase() + "/get_file_url.php?uid=" + uid + "&fid=" + fid + "&file_chk=" + chk + "&verifycode=" + code;
                core.ajax({
                    url: url,
                    dataType: "json",
                    headers: {
                        "Referer": referer
                    },
                    success: function (response) {
                        if (response && response.downurl) {
                            obj._downloads[key] = response;
                        }

                        callback && callback(response);
                    },
                    error: function (error) {
                        callback && callback("");
                    }
                });
            }
        };

        return obj;
    });

    container.define("app_dfpan", ["config", "core", "$"], function (config, core, $) {
        var obj = {};

        obj.run = function () {
            var url = config.getUrl();
            if (url.indexOf("page2.dfpan.com") > 0) {
                $(function () {
                    core.isOptionActive(config.option.yunfile_page_download) && obj.initDownloadPage();
                });
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            setInterval(function () {
                core.getPageWindow().CTAMAT = {};
            }, 100);

            $(".ad-layer").remove();
            $("#common_speed_down").click();
        };

        return obj;
    });

    container.define("app_ccchoo", ["config", "core", "$"], function (config, core, $) {
        var obj = {};

        obj.run = function () {
            var url = config.getUrl();
            if (url.indexOf("ccchoo.com/file") > 0) {
                core.isOptionActive(config.option.ccchoo_auto_jump) && obj.initFilePage();
                return true;
            }
            else if (url.indexOf("ccchoo.com/down2") > 0) {
                core.isOptionActive(config.option.ccchoo_auto_jump) && obj.initDownload2Page();
                return true;
            }
            else if (url.indexOf("ccchoo.com/down") > 0) {
                $(function () {
                    core.isOptionActive(config.option.ccchoo_page_download) && obj.initDownloadPage();
                });
                return true;
            }
            else {
                return false;
            }
        };

        obj.initFilePage = function () {
            var url = config.getUrl();
            location.href = url.replace("/file-", "/down2-");
        };

        obj.initDownload2Page = function () {
            var url = config.getUrl();
            location.href = url.replace("/down2-", "/down-");
        };

        obj.initDownloadPage = function () {
            $("#down_link").hide();
            $(".b-box").show();
            $(".q-box").css("opacity", 0);
        };

        return obj;
    });

    container.define("app_vdisk", ["config", "core", "$"], function (config, core, $) {
        var obj = {};

        obj.run = function () {
            var url = config.getUrl();
            if (url.indexOf("vdisk.cn/down/") > 0) {
                $(function () {
                    core.isOptionActive(config.option.vdisk_page_download) && obj.initDownloadPage();
                });
                return true;
            }
            else {
                return false;
            }
        };

        obj.initDownloadPage = function () {
            $("#loadingbox").hide();
            $("#btnbox").show();
        };

        return obj;
    });

    container.define("app_yimuhe", ["config", "core", "$"], function (config, core, $) {
        var obj = {};

        obj.run = function () {
            var url = config.getUrl();
            if (url.indexOf("yimuhe.com/file") > 0) {
                core.isOptionActive(config.option.yimuhe_auto_jump) && obj.initFilePage();
                return true;
            }
            else if (url.indexOf("yimuhe.com/down") > 0) {
                $(function () {
                    core.isOptionActive(config.option.yimuhe_page_download) && obj.initDownloadPage();
                });
                return true;
            }
            else {
                return false;
            }
        };

        obj.initFilePage = function () {
            var url = config.getUrl();
            location.href = url.replace("/file-", "/down-");
        };

        obj.initDownloadPage = function () {
            var pageWindow = core.getPageWindow();

            // 失效广告事件
            pageWindow.__qy_pop_up_tg.kdopen = function () { };
            pageWindow.__qy_pop_up_tg.reopen = function () { };
            pageWindow.__qy_pop_up_tg.wopen = function () { };
            pageWindow.__qy_pop_up_tg.hrefopen = function () { };
            pageWindow.__qy_pop_up_tg.uinit();

            // 展示验证码
            pageWindow.wait = -1;
            $("#loading").hide();
            $("#yzm").show();

            // 隐藏页面广告
            $("a").each(function () {
                if (this.href && this.href.indexOf("AID") > 0) {
                    $(this).hide();
                }
            });
        };

        return obj;
    });

    container.define("app_newday", ["config", "util", "core", "api", "$", "vue"], function (config, util, core, api, $, vue) {
        var obj = {};

        obj.run = function () {
            if (obj.existMeta("wpzs::option")) {
                obj.initOptionPage();
            }
            else if (obj.existMeta("wpzs::share")) {
                obj.initSharePage();
            }
            return true;
        };

        obj.initOptionPage = function () {
            new vue({
                el: "#container",
                data: {
                    app_id: core.getConfig("app_id"),
                    info: {
                        version: core.getVersion()
                    },
                    option: core.getOption()
                },
                mounted: function () {
                    this.initCheckBox();
                },
                watch: {
                    option: function (value) {
                        core.setOption(value);
                        api.logOption(value);
                    },
                    app_id: function (value) {
                        core.setConfig("app_id", value);
                        api.logOption({
                            app_id: value
                        });
                    }
                },
                methods: {
                    initCheckBox: function () {
                        $("body").addClass("init-checkbox-wait");
                    }
                }
            });
        };

        obj.initSharePage = function () {
            var shareLogList = core.getShareLogList();
            new vue({
                el: "#container",
                data: {
                    info: {
                        version: core.getVersion()
                    },
                    list: []
                },
                mounted: function () {
                    this.loadShareLogList("all");
                },
                methods: {
                    showShareLogList: function (source) {
                        $(".am-nav-tabs .am-active").removeClass("am-active");
                        $(".source-" + source).addClass("am-active");
                        this.loadShareLogList(source);
                    },
                    loadShareLogList: function (source) {
                        this.list = this.processShareLogList(source);
                    },
                    processShareLogList: function (source) {
                        var filterShareLogList = [];
                        Object.keys(shareLogList).forEach(function (shareId) {
                            var shareLog = shareLogList[shareId];
                            if (source == "all" || source == shareLog.share_source) {
                                filterShareLogList.push({
                                    share_id: shareId,
                                    share_pwd: shareLog.share_pwd,
                                    share_link: obj.buildShareLink(shareId, shareLog.share_source, shareLog.share_link),
                                    share_time: obj.buildShareTime(shareLog.share_time)
                                });
                            }
                        });
                        return filterShareLogList.reverse();
                    }
                }
            });
        };

        obj.buildShareLink = function (shareId, shareSource, shareLink) {
            if (shareSource == config.source.baidu) {
                shareLink = "https://pan.baidu.com/s/1" + shareId;
            }
            else if (shareSource == config.source.baidu) {
                shareLink = "https://share.weiyun.com/" + shareId;
            } else if (shareSource == config.source.baidu) {
                shareLink = "https://www.lanzous.com/" + shareId;
            }
            return shareLink;
        };

        obj.buildShareTime = function (shareTime) {
            var date = new Date(shareTime);
            var year = 1900 + date.getYear();
            var month = "0" + (date.getMonth() + 1);
            var day = "0" + date.getDate();
            var hour = "0" + date.getHours();
            var minute = "0" + date.getMinutes();
            var second = "0" + date.getSeconds();
            var vars = {
                "Y": year,
                "m": month.substring(month.length - 2, month.length),
                "d": day.substring(day.length - 2, day.length),
                "H": hour.substring(hour.length - 2, hour.length),
                "i": minute.substring(minute.length - 2, minute.length),
                "s": second.substring(second.length - 2, second.length)
            };
            return util.replaceVars(vars, "Y-m-d H:i:s");

        };

        obj.existMeta = function (name) {
            if ($("meta[name='" + name + "']").length) {
                return true;
            }
            else {
                return false;
            }
        };

        return obj;
    });

    container.define("app", ["config", "core", "$"], function (config, core, $, require) {
        var obj = {
            name: "wpzs"
        };

        obj.run = function () {
            var metaName = obj.name + "::status";
            if (obj.existMeta(metaName)) {
                core.printLog(obj.name + " setup already");
            }
            else {
                core.printLog(obj.name + " setup success");

                // 添加meta
                obj.appendMeta(metaName);

                // 运行应用
                obj.runApp();
            }
        };

        obj.runApp = function () {
            var appList = [
                {
                    name: "app_baidu",
                    matchs: [
                        "baidu.com"
                    ]
                },
                {
                    name: "app_weiyun",
                    matchs: [
                        "weiyun.com"
                    ]
                },
                {
                    name: "app_lanzous",
                    matchs: [
                        "lanzous.com"
                    ]
                },
                {
                    name: "app_weibo",
                    matchs: [
                        "weibo.com"
                    ]
                },
                {
                    name: "app_[ctfile|pipipan]",
                    matchs: [
                        "ctfile.com",
                        "pipipan.com"
                    ]
                },
                {
                    name: "app_dfpan",
                    matchs: [
                        "dfpan.com"
                    ]
                },
                {
                    name: "app_ccchoo",
                    matchs: [
                        "ccchoo.com"
                    ]
                },
                {
                    name: "app_vdisk",
                    matchs: [
                        "vdisk.cn"
                    ]
                },
                {
                    name: "app_yimuhe",
                    matchs: [
                        "yimuhe.com"
                    ]
                },
                {
                    name: "app_newday",
                    matchs: [
                        "newday.me"
                    ]
                }
            ];
            var url = config.getUrl();
            for (var i in appList) {
                var app = appList[i];
                if (obj.matchApp(url, app) && require(app.name).run() == true) {
                    break;
                }
            }
        };

        obj.matchApp = function (url, app) {
            var match = false;
            app.matchs.forEach(function (item) {
                if (url.indexOf(item) > 0) {
                    match = true;
                }
            });
            return match;
        };

        obj.existMeta = function (name) {
            if ($("meta[name='" + name + "']").length) {
                return true;
            }
            else {
                return false;
            }
        };

        obj.appendMeta = function (name, content) {
            content || (content = "on");
            $('<meta name="' + name + '" content="on">').appendTo($("head"));
        };

        return obj;
    });

    // 注册模块
    container.register("$", window.$);
    container.register("snap", window.Snap);
    container.register("vue", window.Vue);

    container.use(["core", "app"], function (core, app) {
        core.init(function () {
            app.run();
        });
    });
})();

// 脚本2 百度云限速破解

(function () {
  'use strict';
  var log_count = 1;
  var classMap = {
    'list': 'zJMtAEb',
    'grid': 'fyQgAEb',
    'list-grid-switch': 'auiaQNyn',
    'list-switched-on': 'ewXm1e',
    'grid-switched-on': 'kxhkX2Em',
    'list-switch': 'rvpXm63',
    'grid-switch': 'mxgdJgwv',
    'checkbox': 'EOGexf',
    'col-item': 'Qxyfvg',
    'check': 'fydGNC',
    'checked': 'EzubGg',
    'chekbox-grid': 'cEefyz',
    'list-view': 'vdAfKMb',
    'item-active': 'zwcb105L',
    'grid-view': 'JKvHJMb',
    'bar-search': 'OFaPaO',
    'list-tools': 'tcuLAu',
  };
  var errorMsg = {
    'dir': '不支持整个文件夹下载，可进入文件夹内获取文件链接下载',
    'unlogin': '提示 : 必须登录百度网盘后才能正常使用脚本哦!!!',
    'fail': '获取下载链接失败！请刷新后重试！',
    'unselected': '未选中文件，请刷新后重试！',
    'morethan2': '多个文件请点击【显示链接】'
  };

  var secretCode = GM_getValue('secretCode') ? GM_getValue('secretCode') : '498065';

  function slog(c1, c2, c3) {
    c1 = c1 ? c1 : '';
    c2 = c2 ? c2 : '';
    c3 = c3 ? c3 : '';
    console.log('#' + ('00' + log_count++).slice(-2) + '-助手日志:', c1, c2, c3);
  }

  //网盘页面的下载助手
  function PanHelper() {
    var yunData, sign, timestamp, bdstoken, logid, fid_list;
    var fileList = [], selectFileList = [], batchLinkList = [], batchLinkListAll = [], linkList = [],
      list_grid_status = 'list';
    var observer, currentPage, currentPath, currentCategory, dialog, searchKey;
    var panAPIUrl = location.protocol + "//" + location.host + "/api/";
    var restAPIUrl = location.protocol + "//pcs.baidu.com/rest/2.0/pcs/";
    var clientAPIUrl = location.protocol + "//d.pcs.baidu.com/rest/2.0/pcs/";

    this.init = function () {
      yunData = unsafeWindow.yunData;
      slog('yunData:', yunData);
      if (yunData === undefined) {
        slog('页面未正常加载，或者百度已经更新！');
        return;
      }
      initParams();
      registerEventListener();
      createObserver();
      addButton();
      createIframe();
      dialog = new Dialog({addCopy: true});
      slog('百度网盘直接下载助手 直链加速版加载成功！');
    };

    function initParams() {
      sign = getSign();
      timestamp = getTimestamp();
      bdstoken = getBDStoken();
      logid = getLogID();
      currentPage = getCurrentPage();
      slog('当前模式:', currentPage);

      if (currentPage == 'all')
        currentPath = getPath();
      if (currentPage == 'category')
        currentCategory = getCategory();
      if (currentPage == 'search')
        searchKey = getSearchKey();
      refreshListGridStatus();
      refreshFileList();
      refreshSelectList();
    }

    function refreshFileList() {
      if (currentPage == 'all') {
        fileList = getFileList();
      } else if (currentPage == 'category') {
        fileList = getCategoryFileList();
      } else if (currentPage == 'search') {
        fileList = getSearchFileList();
      }
    }

    function refreshSelectList() {
      selectFileList = [];
    }

    function refreshListGridStatus() {
      list_grid_status = getListGridStatus();
    }

    //获取当前的视图模式
    function getListGridStatus() {
      if ($('.' + classMap['list']).is(':hidden')) {
        return 'grid'
      } else {
        return 'list'
      }
    }

    function registerEventListener() {
      registerHashChange();
      registerListGridStatus();
      registerCheckbox();
      registerAllCheckbox();
      registerFileSelect();
      registerShareClick();
    }

    //监视点击分享按钮
    function registerShareClick() {
      $(document).on('click', '[title="分享"]', function () {
        var inv = setInterval(function () {
          if ($('#share-method-public').length === 0) {
            $(".share-method-line").parent().append('<div class="share-method-line"><input type="radio" id="share-method-public" name="share-method" value="public" checked><span class="icon radio-icon icon-radio-non"></span><label for="share-method-public"><b>公开分享</b><span>任何人访问链接即可查看，下载！</span></div>');
          } else {
            clearInterval(inv);
            $(document).off('click', '[title="分享"]');
          }
        }, 100);
      });
    }

    //监视地址栏#标签的变化
    function registerHashChange() {
      window.addEventListener('hashchange', function (e) {
        refreshListGridStatus();

        if (getCurrentPage() == 'all') {
          if (currentPage == getCurrentPage()) {
            if (currentPath != getPath()) {
              currentPath = getPath();
              refreshFileList();
              refreshSelectList();
            }
          } else {
            currentPage = getCurrentPage();
            currentPath = getPath();
            refreshFileList();
            refreshSelectList();
          }
        } else if (getCurrentPage() == 'category') {
          if (currentPage == getCurrentPage()) {
            if (currentCategory != getCategory()) {
              currentPage = getCurrentPage();
              currentCategory = getCategory();
              refreshFileList();
              refreshSelectList();
            }
          } else {
            currentPage = getCurrentPage();
            currentCategory = getCategory();
            refreshFileList();
            refreshSelectList();
          }
        } else if (getCurrentPage() == 'search') {
          if (currentPage == getCurrentPage()) {
            if (searchKey != getSearchKey()) {
              currentPage = getCurrentPage();
              searchKey = getSearchKey();
              refreshFileList();
              refreshSelectList();
            }
          } else {
            currentPage = getCurrentPage();
            searchKey = getSearchKey();
            refreshFileList();
            refreshSelectList();
          }
        }
      });
    }

    //监视视图变化
    function registerListGridStatus() {
      var $a_list = $('a[data-type=list]');
      $a_list.click(function () {
        list_grid_status = 'list';
      });

      var $a_grid = $('a[data-type=grid]');
      $a_grid.click(function () {
        list_grid_status = 'grid';
      });
    }

    //文件选择框
    function registerCheckbox() {
      var $checkbox = $('span.' + classMap['checkbox']);
      if (list_grid_status == 'grid') {
        $checkbox = $('.' + classMap['chekbox-grid']);
      }

      $checkbox.each(function (index, element) {
        $(element).bind('click', function (e) {
          var $parent = $(this).parent();
          var filename;
          var isActive;

          if (list_grid_status == 'list') {
            filename = $('div.file-name div.text a', $parent).attr('title');
            isActive = $parent.hasClass(classMap['item-active']);
          } else if (list_grid_status == 'grid') {
            filename = $('div.file-name a', $(this)).attr('title');
            isActive = !$(this).hasClass(classMap['item-active'])
          }

          if (isActive) {
            slog('取消选中文件：' + filename);
            for (var i = 0; i < selectFileList.length; i++) {
              if (selectFileList[i].filename == filename) {
                selectFileList.splice(i, 1);
              }
            }
          } else {
            slog('选中文件:' + filename);
            $.each(fileList, function (index, element) {
              if (element.server_filename == filename) {
                var obj = {
                  filename: element.server_filename,
                  path: element.path,
                  fs_id: element.fs_id,
                  isdir: element.isdir
                };
                selectFileList.push(obj);
              }
            });
          }
        });
      });
    }

    function unregisterCheckbox() {
      var $checkbox = $('span.' + classMap['checkbox']);
      $checkbox.each(function (index, element) {
        $(element).unbind('click');
      });
    }

    //全选框
    function registerAllCheckbox() {
      var $checkbox = $('div.' + classMap['col-item'] + '.' + classMap['check']);
      $checkbox.each(function (index, element) {
        $(element).bind('click', function (e) {
          var $parent = $(this).parent();
          if ($parent.hasClass(classMap['checked'])) {
            slog('取消全选');
            selectFileList = [];
          } else {
            slog('全部选中');
            selectFileList = [];
            $.each(fileList, function (index, element) {
              var obj = {
                filename: element.server_filename,
                path: element.path,
                fs_id: element.fs_id,
                isdir: element.isdir
              };
              selectFileList.push(obj);
            });
          }
        });
      });
    }

    function unregisterAllCheckbox() {
      var $checkbox = $('div.' + classMap['col-item'] + '.' + classMap['check']);
      $checkbox.each(function (index, element) {
        $(element).unbind('click');
      });
    }

    //单个文件选中，点击文件不是点击选中框，会只选中该文件
    function registerFileSelect() {
      var $dd = $('div.' + classMap['list-view'] + ' dd');
      $dd.each(function (index, element) {
        $(element).bind('click', function (e) {
          var nodeName = e.target.nodeName.toLowerCase();
          if (nodeName != 'span' && nodeName != 'a' && nodeName != 'em') {
            slog('shiftKey:' + e.shiftKey);
            if (!e.shiftKey) {
              selectFileList = [];
              var filename = $('div.file-name div.text a', $(this)).attr('title');
              slog('选中文件：' + filename);
              $.each(fileList, function (index, element) {
                if (element.server_filename == filename) {
                  var obj = {
                    filename: element.server_filename,
                    path: element.path,
                    fs_id: element.fs_id,
                    isdir: element.isdir
                  };
                  selectFileList.push(obj);
                }
              });
            } else {
              selectFileList = [];
              var $dd_select = $('div.' + classMap['list-view'] + ' dd.' + classMap['item-active']);
              $.each($dd_select, function (index, element) {
                var filename = $('div.file-name div.text a', $(element)).attr('title');
                slog('选中文件：' + filename);
                $.each(fileList, function (index, element) {
                  if (element.server_filename == filename) {
                    var obj = {
                      filename: element.server_filename,
                      path: element.path,
                      fs_id: element.fs_id,
                      isdir: element.isdir
                    };
                    selectFileList.push(obj);
                  }
                });
              });
            }
          }
        });
      });
    }

    function unregisterFileSelect() {
      var $dd = $('div.' + classMap['list-view'] + ' dd');
      $dd.each(function (index, element) {
        $(element).unbind('click');
      });
    }

    //监视文件列表显示变化
    function createObserver() {
      var MutationObserver = window.MutationObserver;
      var options = {
        'childList': true
      };
      observer = new MutationObserver(function (mutations) {
        unregisterCheckbox();
        unregisterAllCheckbox();
        unregisterFileSelect();
        registerCheckbox();
        registerAllCheckbox();
        registerFileSelect();
      });

      var list_view = document.querySelector('.' + classMap['list-view']);
      var grid_view = document.querySelector('.' + classMap['grid-view']);

      observer.observe(list_view, options);
      observer.observe(grid_view, options);
    }

    //添加助手按钮
    function addButton() {
      $('div.' + classMap['bar-search']).css('width', '18%');
      var $dropdownbutton = $('<span class="g-dropdown-button"></span>');
      var $dropdownbutton_a = $('<a class="g-button g-button-blue" href="javascript:void(0);"><span class="g-button-right"><em class="icon icon-speed" title="百度网盘下载助手"></em><span class="text" style="width: 60px;">下载助手</span></span></a>');
      var $dropdownbutton_span = $('<span class="menu" style="width:104px"></span>');

      var $directbutton = $('<span class="g-button-menu" style="display:block"></span>');
      var $directbutton_span = $('<span class="g-dropdown-button g-dropdown-button-second" menulevel="2"></span>');
      var $directbutton_a = $('<a class="g-button" href="javascript:void(0);"><span class="g-button-right"><span class="text" style="width:auto">直接下载</span></span></a>');
      var $directbutton_menu = $('<span class="menu" style="width:120px;left:79px"></span>');
      var $directbutton_download_button = $('<a id="download-direct" class="g-button-menu" href="javascript:void(0);">下载</a>');
      var $directbutton_link_button = $('<a id="link-direct" class="g-button-menu" href="javascript:void(0);">显示链接</a>');
      var $directbutton_batchhttplink_button = $('<a id="batchhttplink-direct" class="g-button-menu" href="javascript:void(0);">批量链接(HTTP)</a>');
      var $directbutton_batchhttpslink_button = $('<a id="batchhttpslink-direct" class="g-button-menu" href="javascript:void(0);">批量链接(HTTPS)</a>');
      $directbutton_menu.append($directbutton_download_button).append($directbutton_link_button).append($directbutton_batchhttplink_button).append($directbutton_batchhttpslink_button);
      $directbutton.append($directbutton_span.append($directbutton_a).append($directbutton_menu));
      $directbutton.hover(function () {
        $directbutton_span.toggleClass('button-open');
      });
      $directbutton_download_button.click(downloadClick);
      $directbutton_link_button.click(linkClick);
      $directbutton_batchhttplink_button.click(batchClick);
      $directbutton_batchhttpslink_button.click(batchClick);

      var $apibutton = $('<span class="g-button-menu" style="display:block"></span>');
      var $apibutton_span = $('<span class="g-dropdown-button g-dropdown-button-second" menulevel="2"></span>');
      var $apibutton_a = $('<a class="g-button" href="javascript:void(0);"><span class="g-button-right"><span class="text" style="width:auto">API下载</span></span></a>');
      var $apibutton_menu = $('<span class="menu" style="width:120px;left:77px"></span>');
      var $apibutton_download_button = $('<a id="download-api" class="g-button-menu" href="javascript:void(0);">直接下载</a>');
      var $apibutton_batchhttplink_button = $('<a id="batchhttplink-api" class="g-button-menu" href="javascript:void(0);">显示链接</a>');
      var $setting_button = $('<a id="appid-setting" class="g-button-menu" href="javascript:void(0);">脚本配置</a>');
      $apibutton_menu.append($apibutton_download_button).append($apibutton_batchhttplink_button).append($setting_button);
      $apibutton.append($apibutton_span.append($apibutton_a).append($apibutton_menu));
      $apibutton.hover(function () {
        $apibutton_span.toggleClass('button-open');
      });
      $apibutton_download_button.click(downloadClick);
      $apibutton_batchhttplink_button.click(batchClick);
      $setting_button.click(setSetting);

      var $outerlinkbutton = $('<span class="g-button-menu" style="display:block"></span>');
      var $outerlinkbutton_span = $('<span class="g-dropdown-button g-dropdown-button-second" menulevel="2"></span>');
      var $outerlinkbutton_a = $('<a class="g-button" href="javascript:void(0);"><span class="g-button-right"><span class="text" style="width:auto">外链下载</span></span></a>');
      var $outerlinkbutton_menu = $('<span class="menu" style="width:120px;left:79px"></span>');
      var $outerlinkbutton_batchlink_button = $('<a id="batchlink-outerlink" class="g-button-menu" href="javascript:void(0);">显示链接</a>');
      $outerlinkbutton_menu.append($outerlinkbutton_batchlink_button);
      $outerlinkbutton.append($outerlinkbutton_span.append($outerlinkbutton_a).append($outerlinkbutton_menu));
      $outerlinkbutton.hover(function () {
        $outerlinkbutton_span.toggleClass('button-open');
      });
      $outerlinkbutton_batchlink_button.click(batchClick);

      var $github = $('<iframe src="https://ghbtns.com/github-btn.html?user=syhyz1990&repo=baiduyun&type=star&count=true" frameborder="0" scrolling="0" style="height: 20px;max-width: 120px;padding: 0 5px;box-sizing: border-box;margin-top: 5px;"></iframe>');
      //$dropdownbutton_span.append($directbutton).append($apibutton).append($outerlinkbutton);
      $dropdownbutton_span.append($apibutton).append($outerlinkbutton).append($github);
      $dropdownbutton.append($dropdownbutton_a).append($dropdownbutton_span);

      $dropdownbutton.hover(function () {
        $dropdownbutton.toggleClass('button-open');
      });

      $('.' + classMap['list-tools']).append($dropdownbutton);
      $('.' + classMap['list-tools']).css('height', '40px');
    }

    function setSetting() {
      var str = prompt('请输入神秘代码 , 不懂请勿输入 , 否则后果自负', secretCode);
      if(/^\d{1,6}$/.test(str)){
        GM_setValue('secretCode', str)
        alert('神秘代码执行成功 , 点击确定将自动刷新')
        history.go(0)
      }
    }

    // 我的网盘 - 下载
    function downloadClick(event) {
      slog('选中文件列表：', selectFileList);
      var id = event.target.id;
      var downloadLink;

      if (id == 'download-direct') {
        var downloadType;
        if (selectFileList.length === 0) {
          alert(errorMsg.unselected);
          return;
        } else if (selectFileList.length == 1) {
          if (selectFileList[0].isdir === 1)
            downloadType = 'batch';
          else if (selectFileList[0].isdir === 0)
            downloadType = 'dlink';
        } else if (selectFileList.length > 1) {
          downloadType = 'batch';
        }

        fid_list = getFidList(selectFileList);
        var result = getDownloadLinkWithPanAPI(downloadType);
        if (result.errno === 0) {
          if (downloadType == 'dlink')
            downloadLink = result.dlink[0].dlink;
          else if (downloadType == 'batch') {
            downloadLink = result.dlink;
            if (selectFileList.length === 1)
              downloadLink = downloadLink + '&zipname=' + encodeURIComponent(selectFileList[0].filename) + '.zip';
          } else {
            alert("发生错误！");
            return;
          }
        } else if (result.errno == -1) {
          alert('文件不存在或已被百度和谐，无法下载！');
          return;
        } else if (result.errno == 112) {
          alert("页面过期，请刷新重试！");
          return;
        } else {
          alert("发生错误！");
          return;
        }
      } else {
        if (selectFileList.length === 0) {
          alert("获取选中文件失败，请刷新重试！");
          return;
        } else if (selectFileList.length > 1) {
          alert(errorMsg.morethan2);
          return;
        } else {
          if (selectFileList[0].isdir == 1) {
            alert(errorMsg.dir);
            return;
          }
        }
        if (id == 'download-api') {
          downloadLink = getDownloadLinkWithRESTAPIBaidu(selectFileList[0].path);
        }
      }
      execDownload(downloadLink);
    }

    //我的网盘 - 显示链接
    function linkClick(event) {
      slog('选中文件列表：', selectFileList);
      var id = event.target.id;
      var linkList, tip;

      if (id.indexOf('direct') != -1) {
        var downloadType;
        var downloadLink;
        if (selectFileList.length === 0) {
          alert(errorMsg.unselected);
          return;
        } else if (selectFileList.length == 1) {
          if (selectFileList[0].isdir === 1)
            downloadType = 'batch';
          else if (selectFileList[0].isdir === 0)
            downloadType = 'dlink';
        } else if (selectFileList.length > 1) {
          downloadType = 'batch';
        }
        fid_list = getFidList(selectFileList);
        var result = getDownloadLinkWithPanAPI(downloadType);
        if (result.errno === 0) {
          if (downloadType == 'dlink')
            downloadLink = result.dlink[0].dlink;
          else if (downloadType == 'batch') {
            slog(selectFileList);
            downloadLink = result.dlink;
            if (selectFileList.length === 1)
              downloadLink = downloadLink + '&zipname=' + encodeURIComponent(selectFileList[0].filename) + '.zip';
          } else {
            alert("发生错误！");
            return;
          }
        } else if (result.errno == -1) {
          alert('文件不存在或已被百度和谐，无法下载！');
          return;
        } else if (result.errno == 112) {
          alert("页面过期，请刷新重试！");
          return;
        } else {
          alert("发生错误！");
          return;
        }
        var httplink = downloadLink.replace(/^([A-Za-z]+):/, 'http:');
        var httpslink = downloadLink.replace(/^([A-Za-z]+):/, 'https:');
        var filename = '';
        $.each(selectFileList, function (index, element) {
          if (selectFileList.length == 1)
            filename = element.filename;
          else {
            if (index == 0)
              filename = element.filename;
            else
              filename = filename + ',' + element.filename;
          }
        });
        linkList = {
          filename: filename,
          urls: [
            {url: httplink, rank: 1},
            {url: httpslink, rank: 2}
          ]
        };
        tip = '显示模拟百度网盘网页获取的链接，可以使用右键迅雷或IDM下载，多文件打包(限300k)下载的链接可以直接复制使用';
        dialog.open({title: '下载链接', type: 'link', list: linkList, tip: tip});
      } else {
        if (selectFileList.length === 0) {
          alert(errorMsg.unselected);
          return;
        } else if (selectFileList.length > 1) {
          alert(errorMsg.morethan2);
          return;
        } else {
          if (selectFileList[0].isdir == 1) {
            alert(errorMsg.dir);
            return;
          }
        }
        if (id.indexOf('api') != -1) {
          var downloadLink = getDownloadLinkWithRESTAPIBaidu(selectFileList[0].path);
          var httplink = downloadLink.replace(/^([A-Za-z]+):/, 'http:');
          var httpslink = downloadLink.replace(/^([A-Za-z]+):/, 'https:');
          linkList = {
            filename: selectFileList[0].filename,
            urls: [
              {url: httplink, rank: 1},
              {url: httpslink, rank: 2}
            ]
          };

          //linkList.urls.push({url: httpslink, rank: 4});
          tip = '显示模拟APP获取的链接(使用百度云ID)，可以右键使用迅雷或IDM下载，直接复制链接无效';
          dialog.open({title: '下载链接', type: 'link', list: linkList, tip: tip});
        } else if (id.indexOf('outerlink') != -1) {
          getDownloadLinkWithClientAPI(selectFileList[0].path, function (result) {
            if (result.errno == 0) {
              linkList = {
                filename: selectFileList[0].filename,
                urls: result.urls
              };
            } else if (result.errno == 1) {
              alert('文件不存在！');
              return;
            } else if (result.errno == 2) {
              alert('文件不存在或者已被百度和谐，无法下载！');
              return;
            } else {
              alert('发生错误！');
              return;
            }
            tip = '左键点击调用IDM下载（<b>复制链接无效</b>）';
            dialog.open({
              title: '下载链接',
              type: 'GMlink',
              list: linkList,
              tip: tip,
              showcopy: false,
              showedit: false
            });
          });
        }
      }
    }

    // 我的网盘 - 批量下载
    function batchClick(event) {
      slog('选中文件列表：', selectFileList);
      if (selectFileList.length === 0) {
        alert(errorMsg.unselected);
        return;
      }
      var id = event.target.id;
      var linkType, tip;
      linkType = id.indexOf('https') == -1 ? (id.indexOf('http') == -1 ? location.protocol + ':' : 'http:') : 'https:';
      batchLinkList = [];
      batchLinkListAll = [];
      if (id.indexOf('direct') != -1) {
        batchLinkList = getDirectBatchLink(linkType);
        tip = '显示所有选中文件的直接下载链接，文件夹显示为打包下载的链接';
        if (batchLinkList.length === 0) {
          alert('没有链接可以显示，API链接不要全部选中文件夹！');
          return;
        }
        dialog.open({title: '批量链接', type: 'batch', list: batchLinkList, tip: tip, showcopy: true});
      } else if (id.indexOf('api') != -1) {
        batchLinkList = getAPIBatchLink(linkType);
        tip = '直接复制链接无效，请安装 IDM 及浏览器扩展后使用（<a href="https://github.com/syhyz1990/baiduyun/wiki/脚本使用说明" target="_blank">脚本使用说明</a>）';
        if (batchLinkList.length === 0) {
          alert('没有链接可以显示，API链接不要全部选中文件夹！');
          return;
        }
        dialog.open({title: '批量链接', type: 'batch', list: batchLinkList, tip: tip, showcopy: true});
      } else if (id.indexOf('outerlink') != -1) {
        getOuterlinkBatchLinkAll(function (batchLinkListAll) {
          batchLinkList = getOuterlinkBatchLinkFirst(batchLinkListAll);
          tip = '左键点击调用IDM下载，推荐all开头的地址（<b>复制链接无效</b>）';
          if (batchLinkList.length === 0) {
            alert('没有链接可以显示，API链接不要全部选中文件夹！');
            return;
          }

          dialog.open({
            title: '批量链接',
            type: 'GMbatch',
            list: batchLinkList,
            tip: tip,
            showcopy: true,
            alllist: batchLinkListAll,
            showall: true
          });
        });
      }
    }

    function getDirectBatchLink(linkType) {
      var list = [];
      $.each(selectFileList, function (index, element) {
        var downloadType, downloadLink, result;
        if (element.isdir == 0)
          downloadType = 'dlink';
        else
          downloadType = 'batch';
        fid_list = getFidList([element]);
        result = getDownloadLinkWithPanAPI(downloadType);
        if (result.errno == 0) {
          if (downloadType == 'dlink')
            downloadLink = result.dlink[0].dlink;
          else if (downloadType == 'batch')
            downloadLink = result.dlink;
          downloadLink = downloadLink.replace(/^([A-Za-z]+):/, linkType);
        } else {
          downloadLink = 'error';
        }
        list.push({filename: element.filename, downloadlink: downloadLink});
      });
      return list;
    }

    function getAPIBatchLink(linkType) {
      var list = [];
      $.each(selectFileList, function (index, element) {
        if (element.isdir == 1)
          return;
        var downloadLink;
        downloadLink = getDownloadLinkWithRESTAPIBaidu(element.path);
        downloadLink = downloadLink.replace(/^([A-Za-z]+):/, linkType);
        list.push({filename: element.filename, downloadlink: downloadLink});
      });
      return list;
    }

    function getOuterlinkBatchLinkAll(cb) {
      $.each(selectFileList, function (index, element) {
        if (element.isdir == 1)
          return;
        getDownloadLinkWithClientAPI(element.path, function (result) {
          var list = [];
          if (result.errno == 0) {
            list.push({filename: element.filename, links: result.urls});
          } else {
            list.push({filename: element.filename, links: [{rank: 1, url: 'error'}]});
          }
          cb(list)
        });
      });
    }

    function getOuterlinkBatchLinkFirst(list) {
      var result = [];
      $.each(list, function (index, element) {
        result.push({filename: element.filename, downloadlink: element.links[0].url});
      });
      return result;
    }

    function getSign() {
      var signFnc;
      try {
        signFnc = new Function("return " + yunData.sign2)();
      } catch (e) {
        throw new Error(e.message);
      }
      return base64Encode(signFnc(yunData.sign5, yunData.sign1));
    }

    //获取当前目录
    function getPath() {
      var hash = location.hash;
      var regx = new RegExp("path=([^&]*)(&|$)", 'i');
      var result = hash.match(regx);
      //console.log(result);
      return decodeURIComponent(result[1]);
    }

    //获取分类显示的类别，即地址栏中的type
    function getCategory() {
      var hash = location.hash;
      var regx = new RegExp("type=([^&]*)(&|$)", 'i');
      var result = hash.match(regx);
      return decodeURIComponent(result[1]);
    }

    function getSearchKey() {
      var hash = location.hash;
      var regx = new RegExp("key=([^&]*)(&|$)", 'i');
      var result = hash.match(regx);
      return decodeURIComponent(result[1]);
    }

    //获取当前页面(all或者category或search)
    function getCurrentPage() {
      var hash = location.hash;
      return hash.substring(hash.indexOf('#') + 2, hash.indexOf('?'));
    }

    //获取文件列表
    function getFileList() {
      var filelist = [];
      var listUrl = panAPIUrl + "list";
      var path = getPath();
      logid = getLogID();
      var params = {
        dir: path,
        bdstoken: bdstoken,
        logid: logid,
        order: 'size',
        desc: 0,
        clienttype: 0,
        showempty: 0,
        web: 1,
        channel: 'chunlei',
        appid: secretCode
      };

      $.ajax({
        url: listUrl,
        async: false,
        method: 'GET',
        data: params,
        success: function (response) {
          filelist = 0 === response.errno ? response.list : [];
        }
      });
      return filelist;
    }

    //获取分类页面下的文件列表
    function getCategoryFileList() {
      var filelist = [];
      var listUrl = panAPIUrl + "categorylist";
      var category = getCategory();
      logid = getLogID();
      var params = {
        category: category,
        bdstoken: bdstoken,
        logid: logid,
        order: 'size',
        desc: 0,
        clienttype: 0,
        showempty: 0,
        web: 1,
        channel: 'chunlei',
        appid: secretCode
      };
      $.ajax({
        url: listUrl,
        async: false,
        method: 'GET',
        data: params,
        success: function (response) {
          filelist = 0 === response.errno ? response.info : [];
        }
      });
      return filelist;
    }

    function getSearchFileList() {
      var filelist = [];
      var listUrl = panAPIUrl + 'search';
      logid = getLogID();
      searchKey = getSearchKey();
      var params = {
        recursion: 1,
        order: 'time',
        desc: 1,
        showempty: 0,
        web: 1,
        page: 1,
        num: 100,
        key: searchKey,
        channel: 'chunlei',
        app_id: 250258,
        bdstoken: bdstoken,
        logid: logid,
        clienttype: 0
      };
      $.ajax({
        url: listUrl,
        async: false,
        method: 'GET',
        data: params,
        success: function (response) {
          filelist = 0 === response.errno ? response.list : [];
        }
      });
      return filelist;
    }

    //生成下载时的fid_list参数
    function getFidList(list) {
      var fidlist = null;
      if (list.length === 0)
        return null;
      var fileidlist = [];
      $.each(list, function (index, element) {
        fileidlist.push(element.fs_id);
      });
      fidlist = '[' + fileidlist + ']';
      return fidlist;
    }

    function getTimestamp() {
      return yunData.timestamp;
    }

    function getBDStoken() {
      return yunData.MYBDSTOKEN;
    }

    //获取直接下载地址
    //这个地址不是直接下载地址，访问这个地址会返回302，response header中的location才是真实下载地址
    //暂时没有找到提取方法
    function getDownloadLinkWithPanAPI(type) {
      var downloadUrl = panAPIUrl + "download";
      var result;
      logid = getLogID();
      var params = {
        sign: sign,
        timestamp: timestamp,
        fidlist: fid_list,
        type: type,
        channel: 'chunlei',
        web: 1,
        app_id: secretCode,
        bdstoken: bdstoken,
        logid: logid,
        clienttype: 0
      };
      $.ajax({
        url: downloadUrl,
        async: false,
        method: 'GET',
        data: params,
        success: function (response) {
          result = response;
        }
      });
      return result;
    }

    function getDownloadLinkWithRESTAPIBaidu(path) {
      var link = restAPIUrl + 'file?method=download&path=' + encodeURIComponent(path) + '&random=' + Math.random() + '&app_id=' + secretCode;
      return link;
    }

    function getDownloadLinkWithClientAPI(path, cb) {
      var result;
      var url = clientAPIUrl + 'file?method=locatedownload&app_id='+secretCode+'&ver=4.0&path=' + encodeURIComponent(path);

      GM_xmlhttpRequest({
        method: "POST",
        url: url,
        headers: {
          "User-Agent": "netdisk;6.7.1.9;PC;PC-Windows;10.0.17763;WindowsBaiduYunGuanJia",
        },
        onload: function (res) {
          if (res.status === 200) {
            result = JSON.parse(res.responseText);
            if (result.error_code == undefined) {
              if (result.urls == undefined) {
                result.errno = 2;
              } else {
                $.each(result.urls, function (index, element) {
                  result.urls[index].url = element.url.replace('\\', '');
                });
                result.errno = 0;
              }
            } else if (result.error_code == 31066) {
              result.errno = 1;
            } else {
              result.errno = -1;
            }
          } else {
            result = {};
            result.errno = -1;
          }
          cb(result)
        }
      });
    }

    function execDownload(link) {
      slog("下载链接：" + link);
      $('#helperdownloadiframe').attr('src', link);
    }

    function createIframe() {
      var $div = $('<div class="helper-hide" style="padding:0;margin:0;display:block"></div>');
      var $iframe = $('<iframe src="javascript:void(0)" id="helperdownloadiframe" style="display:none"></iframe>');
      $div.append($iframe);
      $('body').append($div);

    }
  }

  //分享页面的下载助手
  function PanShareHelper() {
    var yunData, sign, timestamp, bdstoken, channel, clienttype, web, app_id, logid, encrypt, product, uk,
      primaryid, fid_list, extra, shareid;
    var vcode;
    var shareType, buttonTarget, currentPath, list_grid_status, observer, dialog, vcodeDialog;
    var fileList = [], selectFileList = [];
    var panAPIUrl = location.protocol + "//" + location.host + "/api/";
    var shareListUrl = location.protocol + "//" + location.host + "/share/list";

    this.init = function () {
      yunData = unsafeWindow.yunData;
      slog('yunData:', yunData);
      if (yunData === undefined || yunData.FILEINFO == null) {
        slog('页面未正常加载，或者百度已经更新！');
        return;
      }
      initParams();
      addButton();
      dialog = new Dialog({addCopy: false});
      vcodeDialog = new VCodeDialog(refreshVCode, confirmClick);
      createIframe();

      if (!isSingleShare()) {
        registerEventListener();
        createObserver();
      }

      slog('分享助手加载成功!');
    };

    function initParams() {
      shareType = getShareType();
      sign = yunData.SIGN;
      timestamp = yunData.TIMESTAMP;
      bdstoken = yunData.MYBDSTOKEN;
      channel = 'chunlei';
      clienttype = 0;
      web = 1;
      app_id = 250528;
      logid = getLogID();
      encrypt = 0;
      product = 'share';
      primaryid = yunData.SHARE_ID;
      uk = yunData.SHARE_UK;

      if (shareType == 'secret') {
        extra = getExtra();
      }
      if (isSingleShare()) {
        var obj = {};
        if (yunData.CATEGORY == 2) {
          obj.filename = yunData.FILENAME;
          obj.path = yunData.PATH;
          obj.fs_id = yunData.FS_ID;
          obj.isdir = 0;
        } else {
          obj.filename = yunData.FILEINFO[0].server_filename,
            obj.path = yunData.FILEINFO[0].path,
            obj.fs_id = yunData.FILEINFO[0].fs_id,
            obj.isdir = yunData.FILEINFO[0].isdir
        }
        selectFileList.push(obj);
      } else {
        shareid = yunData.SHARE_ID;
        currentPath = getPath();
        list_grid_status = getListGridStatus();
        fileList = getFileList();
      }
    }

    //判断分享类型（public或者secret）
    function getShareType() {
      return yunData.SHARE_PUBLIC === 1 ? 'public' : 'secret';
    }

    //判断是单个文件分享还是文件夹或者多文件分享
    function isSingleShare() {
      return yunData.getContext === undefined ? true : false;
    }

    //判断是否为自己的分享链接
    function isSelfShare() {
      return yunData.MYSELF == 1 ? true : false;
    }

    function getExtra() {
      var seKey = decodeURIComponent(getCookie('BDCLND'));
      return '{' + '"sekey":"' + seKey + '"' + "}";
    }

    //获取当前目录
    function getPath() {
      var hash = location.hash;
      var regx = new RegExp("path=([^&]*)(&|$)", 'i');
      var result = hash.match(regx);
      return decodeURIComponent(result[1]);
    }

    //获取当前的视图模式
    function getListGridStatus() {
      var status = 'list';
      if ($('.list-switched-on').length > 0) {
        status = 'list';
      } else if ($('.grid-switched-on').length > 0) {
        status = 'grid';
      }
      return status;
    }

    //添加下载助手按钮
    function addButton() {
      if (isSingleShare()) {
        $('div.slide-show-right').css('width', '500px');
        $('div.frame-main').css('width', '96%');
        $('div.share-file-viewer').css('width', '740px').css('margin-left', 'auto').css('margin-right', 'auto');
      } else
        $('div.slide-show-right').css('width', '500px');
      var $dropdownbutton = $('<span class="g-dropdown-button"></span>');
      var $dropdownbutton_a = $('<a class="g-button g-button-blue" data-button-id="b200" data-button-index="200" href="javascript:void(0);"></a>');
      var $dropdownbutton_a_span = $('<span class="g-button-right"><em class="icon icon-speed" title="百度网盘下载助手"></em><span class="text" style="width: 60px;">下载助手</span></span>');
      var $dropdownbutton_span = $('<span class="menu" style="width:auto;z-index:41"></span>');

      var $downloadButton = $('<a data-menu-id="b-menu207" class="g-button-menu" href="javascript:void(0);">直接下载</a>');
      var $linkButton = $('<a data-menu-id="b-menu208" class="g-button-menu" href="javascript:void(0);">显示链接</a>');
      var $outlinkButton = $('<a data-menu-id="b-menu209" class="g-button-menu" href="javascript:void(0);">高速下载(beta)</a>');

      var $github = $('<iframe src="https://ghbtns.com/github-btn.html?user=syhyz1990&repo=baiduyun&type=star&count=true" frameborder="0" scrolling="0" style="height: 20px;max-width: 108px;padding: 0 5px;box-sizing: border-box;margin-top: 5px;"></iframe>');

      $dropdownbutton_span.append($downloadButton).append($linkButton).append($outlinkButton).append($github);
      $dropdownbutton_a.append($dropdownbutton_a_span);
      $dropdownbutton.append($dropdownbutton_a).append($dropdownbutton_span);

      $dropdownbutton.hover(function () {
        $dropdownbutton.toggleClass('button-open');
      });

      $downloadButton.click(function () {
        alert('温馨提示 : 百度接口限制, 请先保存到自己网盘 , 去网盘中使用下载助手!!!')
      });
      $linkButton.click(function () {
        alert('温馨提示 : 百度接口限制, 请先保存到自己网盘 , 去网盘中使用下载助手!!!')
      });
      /*$downloadButton.click(downloadButtonClick);
      $linkButton.click(linkButtonClick);*/
      $outlinkButton.click(outlinkButtonClick)

      $('div.module-share-top-bar div.bar div.x-button-box').append($dropdownbutton);
    }

    function outlinkButtonClick() {
      var link = location.href;
      link = link.replace('baidu.com','baiduwp.com');
      GM_openInTab(link, { active: true });
    }

    function createIframe() {
      var $div = $('<div class="helper-hide" style="padding:0;margin:0;display:block"></div>');
      var $iframe = $('<iframe src="javascript:void(0)" id="helperdownloadiframe" style="display:none"></iframe>');
      $div.append($iframe);
      $('body').append($div);
    }

    function registerEventListener() {
      registerHashChange();
      registerListGridStatus();
      registerCheckbox();
      registerAllCheckbox();
      registerFileSelect();
    }

    //监视地址栏#标签变化
    function registerHashChange() {
      window.addEventListener('hashchange', function (e) {
        list_grid_status = getListGridStatus();
        if (currentPath == getPath()) {

        } else {
          currentPath = getPath();
          refreshFileList();
          refreshSelectFileList();
        }
      });
    }

    function refreshFileList() {
      fileList = getFileList();
    }

    function refreshSelectFileList() {
      selectFileList = [];
    }

    //监视视图变化
    function registerListGridStatus() {
      var $a_list = $('a[data-type=list]');
      $a_list.click(function () {
        list_grid_status = 'list';
      });

      var $a_grid = $('a[data-type=grid]');
      $a_grid.click(function () {
        list_grid_status = 'grid';
      });
    }

    //监视文件选择框
    function registerCheckbox() {
      var $checkbox = $('span.' + classMap['checkbox']);
      if (list_grid_status == 'grid') {
        $checkbox = $('.' + classMap['chekbox-grid']);
      }
      $checkbox.each(function (index, element) {
        $(element).bind('click', function (e) {
          var $parent = $(this).parent();
          var filename;
          var isActive;

          if (list_grid_status == 'list') {
            filename = $('div.file-name div.text a', $parent).attr('title');
            isActive = $(this).parents('dd').hasClass('JS-item-active')
          } else if (list_grid_status == 'grid') {
            filename = $('div.file-name a', $(this)).attr('title');
            isActive = !$(this).hasClass('JS-item-active')
          }

          if (isActive) {
            slog('取消选中文件：' + filename);
            for (var i = 0; i < selectFileList.length; i++) {
              if (selectFileList[i].filename == filename) {
                selectFileList.splice(i, 1);
              }
            }
          } else {
            slog('选中文件: ' + filename);
            $.each(fileList, function (index, element) {
              if (element.server_filename == filename) {
                var obj = {
                  filename: element.server_filename,
                  path: element.path,
                  fs_id: element.fs_id,
                  isdir: element.isdir
                };
                selectFileList.push(obj);
              }
            });
          }
        });
      });
    }

    function unregisterCheckbox() {
      var $checkbox = $('span.' + classMap['checkbox']);
      $checkbox.each(function (index, element) {
        $(element).unbind('click');
      });
    }

    //监视全选框
    function registerAllCheckbox() {
      var $checkbox = $('div.' + classMap['col-item'] + '.' + classMap['check']);
      $checkbox.each(function (index, element) {
        $(element).bind('click', function (e) {
          var $parent = $(this).parent();
          if ($parent.hasClass(classMap['checked'])) {
            slog('取消全选');
            selectFileList = [];
          } else {
            slog('全部选中');
            selectFileList = [];
            $.each(fileList, function (index, element) {
              var obj = {
                filename: element.server_filename,
                path: element.path,
                fs_id: element.fs_id,
                isdir: element.isdir
              };
              selectFileList.push(obj);
            });
          }
        });
      });
    }

    function unregisterAllCheckbox() {
      var $checkbox = $('div.' + classMap['col-item'] + '.' + classMap['check']);
      $checkbox.each(function (index, element) {
        $(element).unbind('click');
      });
    }

    //监视单个文件选中
    function registerFileSelect() {
      var $dd = $('div.' + classMap['list-view'] + ' dd');
      $dd.each(function (index, element) {
        $(element).bind('click', function (e) {
          var nodeName = e.target.nodeName.toLowerCase();
          if (nodeName != 'span' && nodeName != 'a' && nodeName != 'em') {
            selectFileList = [];
            var filename = $('div.file-name div.text a', $(this)).attr('title');
            slog('选中文件：' + filename);
            $.each(fileList, function (index, element) {
              if (element.server_filename == filename) {
                var obj = {
                  filename: element.server_filename,
                  path: element.path,
                  fs_id: element.fs_id,
                  isdir: element.isdir
                };
                selectFileList.push(obj);
              }
            });
          }
        });
      });
    }

    function unregisterFileSelect() {
      var $dd = $('div.' + classMap['list-view'] + ' dd');
      $dd.each(function (index, element) {
        $(element).unbind('click');
      });
    }

    //监视文件列表显示变化
    function createObserver() {
      var MutationObserver = window.MutationObserver;
      var options = {
        'childList': true
      };
      observer = new MutationObserver(function (mutations) {
        unregisterCheckbox();
        unregisterAllCheckbox();
        unregisterFileSelect();
        registerCheckbox();
        registerAllCheckbox();
        registerFileSelect();
      });

      var list_view = document.querySelector('.' + classMap['list-view']);
      var grid_view = document.querySelector('.' + classMap['grid-view']);

      observer.observe(list_view, options);
      observer.observe(grid_view, options);
    }

    //获取文件信息列表
    function getFileList() {
      var result = [];
      if (getPath() == '/') {
        result = yunData.FILEINFO;
      } else {
        logid = getLogID();
        var params = {
          uk: uk,
          shareid: shareid,
          order: 'other',
          desc: 1,
          showempty: 0,
          web: web,
          dir: getPath(),
          t: Math.random(),
          bdstoken: bdstoken,
          channel: channel,
          clienttype: clienttype,
          app_id: app_id,
          logid: logid
        };
        $.ajax({
          url: shareListUrl,
          method: 'GET',
          async: false,
          data: params,
          success: function (response) {
            if (response.errno === 0) {
              result = response.list;
            }
          }
        });
      }
      return result;
    }

    function downloadButtonClick() {
      slog('选中文件列表：', selectFileList);
      if (selectFileList.length === 0) {
        alert(errorMsg.unselected);
        return;
      }
      if (selectFileList.length > 1) {
        return alert(errorMsg.morethan2);
      }

      if (selectFileList[0].isdir == 1) {
        return alert(errorMsg.dir);
      }
      buttonTarget = 'download';
      var downloadLink = getDownloadLink();

      if (downloadLink === undefined) return;

      if (downloadLink.errno == -20) {
        vcode = getVCode();
        if (vcode.errno !== 0) {
          alert('获取验证码失败！');
          return;
        }
        vcodeDialog.open(vcode);
      } else if (downloadLink.errno == 112) {
        alert('页面过期，请刷新重试');

      } else if (downloadLink.errno === 0) {
        var link = downloadLink.list[0].dlink;
        execDownload(link);
      } else {
        alert(errorMsg.fail);

      }
    }

    //获取验证码
    function getVCode() {
      var url = panAPIUrl + 'getvcode';
      var result;
      logid = getLogID();
      var params = {
        prod: 'pan',
        t: Math.random(),
        bdstoken: bdstoken,
        channel: channel,
        clienttype: clienttype,
        web: web,
        app_id: app_id,
        logid: logid
      };
      $.ajax({
        url: url,
        method: 'GET',
        async: false,
        data: params,
        success: function (response) {
          result = response;
        }
      });
      return result;
    }

    //刷新验证码
    function refreshVCode() {
      vcode = getVCode();
      $('#dialog-img').attr('src', vcode.img);
    }

    //验证码确认提交
    function confirmClick() {
      var val = $('#dialog-input').val();
      if (val.length === 0) {
        $('#dialog-err').text('请输入验证码');
        return;
      } else if (val.length < 4) {
        $('#dialog-err').text('验证码输入错误，请重新输入');
        return;
      }
      var result = getDownloadLinkWithVCode(val);
      if (result.errno == -20) {
        vcodeDialog.close();
        $('#dialog-err').text('验证码输入错误，请重新输入');
        refreshVCode();
        if (!vcode || vcode.errno !== 0) {
          alert('获取验证码失败！');
          return;
        }
        vcodeDialog.open();
      } else if (result.errno === 0) {
        vcodeDialog.close();
        if (buttonTarget == 'download') {
          if (result.list.length > 1 || result.list[0].isdir == 1) {
            return alert(errorMsg.morethan2);
          }
          var link = result.list[0].dlink;
          execDownload(link);
        } else if (buttonTarget == 'link') {
          var tip = '直接复制链接无效，请安装 IDM 及浏览器扩展后使用（<a href="https://github.com/syhyz1990/baiduyun/wiki/脚本使用说明" target="_blank">脚本使用说明</a>）';
          dialog.open({title: '下载链接（仅显示文件链接）', type: 'shareLink', list: result.list, tip: tip});
        }
      } else {
        alert('发生错误！');

      }
    }

    //生成下载用的fid_list参数
    function getFidList() {
      var fidlist = [];
      $.each(selectFileList, function (index, element) {
        fidlist.push(element.fs_id);
      });
      return '[' + fidlist + ']';
    }

    function linkButtonClick() {
      slog('选中文件列表：', selectFileList);
      if (selectFileList.length === 0) {
        return alert(errorMsg.unselected);
      }
      if (selectFileList[0].isdir == 1) {
        return alert(errorMsg.dir);
      }

      buttonTarget = 'link';
      var downloadLink = getDownloadLink();

      if (downloadLink === undefined) return;

      if (downloadLink.errno == -20) {
        vcode = getVCode();
        if (!vcode || vcode.errno !== 0) {
          return alert('获取验证码失败！');
        }
        vcodeDialog.open(vcode);
      } else if (downloadLink.errno == 112) {
        return alert('页面过期，请刷新重试');
      } else if (downloadLink.errno === 0) {
        var tip = "显示获取的链接，可以使用右键迅雷或IDM下载，复制无用，需要传递cookie";
        dialog.open({title: '下载链接（仅显示文件链接）', type: 'shareLink', list: downloadLink.list, tip: tip});
      } else {
        alert(errorMsg.fail);
      }
    }

    //获取下载链接
    function getDownloadLink() {
      if (bdstoken === null) {
        alert(errorMsg.unlogin);
        return '';
      } else {
        var result;
        if (isSingleShare) {
          fid_list = getFidList();
          logid = getLogID();
          var url = panAPIUrl + 'sharedownload?sign=' + sign + '&timestamp=' + timestamp + '&bdstoken=' + bdstoken + '&channel=' + channel + '&clienttype=' + clienttype + '&web=' + web + '&app_id=' + app_id + '&logid=' + logid;
          var params = {
            encrypt: encrypt,
            product: product,
            uk: uk,
            primaryid: primaryid,
            fid_list: fid_list
          };
          if (shareType == 'secret') {
            params.extra = extra;
          }
          /*if (selectFileList[0].isdir == 1 || selectFileList.length > 1) {
            params.type = 'batch';
          }*/
          $.ajax({
            url: url,
            method: 'POST',
            async: false,
            data: params,
            success: function (response) {
              result = response;
            }
          });
        }
        return result;
      }
    }

    //有验证码输入时获取下载链接
    function getDownloadLinkWithVCode(vcodeInput) {
      var result;
      if (isSingleShare) {
        fid_list = getFidList();
        var url = panAPIUrl + 'sharedownload?sign=' + sign + '&timestamp=' + timestamp + '&bdstoken=' + bdstoken + '&channel=' + channel + '&clienttype=' + clienttype + '&web=' + web + '&app_id=' + app_id + '&logid=' + logid;
        var params = {
          encrypt: encrypt,
          product: product,
          vcode_input: vcodeInput,
          vcode_str: vcode.vcode,
          uk: uk,
          primaryid: primaryid,
          fid_list: fid_list
        };
        if (shareType == 'secret') {
          params.extra = extra;
        }
        /*if (selectFileList[0].isdir == 1 || selectFileList.length > 1) {
          params.type = 'batch';
        }*/
        $.ajax({
          url: url,
          method: 'POST',
          async: false,
          data: params,
          success: function (response) {
            result = response;
          }
        });
      }
      return result;
    }

    function execDownload(link) {
      slog('下载链接：' + link);
      $('#helperdownloadiframe').attr('src', link);
    }
  }

  function base64Encode(t) {
    var a, r, e, n, i, s, o = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (e = t.length, r = 0, a = ""; e > r;) {
      if (n = 255 & t.charCodeAt(r++), r == e) {
        a += o.charAt(n >> 2);
        a += o.charAt((3 & n) << 4);
        a += "==";
        break;
      }
      if (i = t.charCodeAt(r++), r == e) {
        a += o.charAt(n >> 2);
        a += o.charAt((3 & n) << 4 | (240 & i) >> 4);
        a += o.charAt((15 & i) << 2);
        a += "=";
        break;
      }
      s = t.charCodeAt(r++);
      a += o.charAt(n >> 2);
      a += o.charAt((3 & n) << 4 | (240 & i) >> 4);
      a += o.charAt((15 & i) << 2 | (192 & s) >> 6);
      a += o.charAt(63 & s);
    }
    return a;
  }

  function detectPage() {
    var regx = /[\/].+[\/]/g;
    var page = location.pathname.match(regx);
    return page[0].replace(/\//g, '');
  }

  function getCookie(e) {
    var o, t;
    var n = document, c = decodeURI;
    return n.cookie.length > 0 && (o = n.cookie.indexOf(e + "="), -1 != o) ? (o = o + e.length + 1, t = n.cookie.indexOf(";", o), -1 == t && (t = n.cookie.length), c(n.cookie.substring(o, t))) : "";
  }

  function getLogID() {
    var name = "BAIDUID";
    var u = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/~！@#￥%……&";
    var d = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g;
    var f = String.fromCharCode;

    function l(e) {
      if (e.length < 2) {
        var n = e.charCodeAt(0);
        return 128 > n ? e : 2048 > n ? f(192 | n >>> 6) + f(128 | 63 & n) : f(224 | n >>> 12 & 15) + f(128 | n >>> 6 & 63) + f(128 | 63 & n);
      }
      var n = 65536 + 1024 * (e.charCodeAt(0) - 55296) + (e.charCodeAt(1) - 56320);
      return f(240 | n >>> 18 & 7) + f(128 | n >>> 12 & 63) + f(128 | n >>> 6 & 63) + f(128 | 63 & n);
    }

    function g(e) {
      return (e + "" + Math.random()).replace(d, l);
    }

    function m(e) {
      var n = [0, 2, 1][e.length % 3];
      var t = e.charCodeAt(0) << 16 | (e.length > 1 ? e.charCodeAt(1) : 0) << 8 | (e.length > 2 ? e.charCodeAt(2) : 0);
      var o = [u.charAt(t >>> 18), u.charAt(t >>> 12 & 63), n >= 2 ? "=" : u.charAt(t >>> 6 & 63), n >= 1 ? "=" : u.charAt(63 & t)];
      return o.join("");
    }

    function h(e) {
      return e.replace(/[\s\S]{1,3}/g, m);
    }

    function p() {
      return h(g((new Date()).getTime()));
    }

    function w(e, n) {
      return n ? p(String(e)).replace(/[+\/]/g, function (e) {
        return "+" == e ? "-" : "_";
      }).replace(/=/g, "") : p(String(e));
    }

    return w(getCookie(name));
  }

  function Dialog() {
    var linkList = [];
    var showParams;
    var dialog, shadow;

    function createDialog() {
      var screenWidth = document.body.clientWidth;
      var dialogLeft = screenWidth > 800 ? (screenWidth - 800) / 2 : 0;
      var $dialog_div = $('<div class="dialog" style="width: 800px; top: 0px; bottom: auto; left: ' + dialogLeft + 'px; right: auto; display: hidden; visibility: visible; z-index: 52;"></div>');
      var $dialog_header = $('<div class="dialog-header"><h3><span class="dialog-title" style="display:inline-block;width:740px;white-space:nowrap;overflow-x:hidden;text-overflow:ellipsis"></span></h3></div>');
      var $dialog_control = $('<div class="dialog-control"><span class="dialog-icon dialog-close">×</span></div>');
      var $dialog_body = $('<div class="dialog-body" style="max-height:450px;overflow-y:auto;padding:0 20px;"></div>');
      var $dialog_tip = $('<div class="dialog-tip" style="padding-left:20px;background-color:#fff;border-top: 1px solid #c4dbfe;color: #dc373c;"><p></p></div>');

      $dialog_div.append($dialog_header.append($dialog_control)).append($dialog_body);

      //var $dialog_textarea = $('<textarea class="dialog-textarea" style="display:none;width"></textarea>');
      var $dialog_radio_div = $('<div class="dialog-radio" style="display:none;width:760px;padding-left:20px;padding-right:20px"></div>');
      var $dialog_radio_multi = $('<input type="radio" name="showmode" checked="checked" value="multi"><span>多行</span>');
      var $dialog_radio_single = $('<input type="radio" name="showmode" value="single"><span>单行</span>');
      $dialog_radio_div.append($dialog_radio_multi).append($dialog_radio_single);
      $dialog_div.append($dialog_radio_div);
      $('input[type=radio][name=showmode]', $dialog_radio_div).change(function () {
        var value = this.value;
        var $textarea = $('div.dialog-body textarea[name=dialog-textarea]', dialog);
        var content = $textarea.val();
        if (value == 'multi') {
          content = content.replace(/\s+/g, '\n');
          $textarea.css('height', '300px');
        } else if (value == 'single') {
          content = content.replace(/\n+/g, ' ');
          $textarea.css('height', '');
        }
        $textarea.val(content);
      });

      var $dialog_button = $('<div class="dialog-button" style="display:none"></div>');
      var $dialog_button_div = $('<div style="display:table;margin:auto"></div>');
      var $dialog_copy_button = $('<button id="dialog-copy-button" style="display:none;width: 100px; margin: 5px 0 10px 0; cursor: pointer; background: #cc3235; border: none; height: 30px; color: #fff; border-radius: 3px;">直接复制无效</button>');
      var $dialog_edit_button = $('<button id="dialog-edit-button" style="display:none">编辑</button>');
      var $dialog_exit_button = $('<button id="dialog-exit-button" style="display:none">退出</button>');

      $dialog_button_div.append($dialog_copy_button).append($dialog_edit_button).append($dialog_exit_button);
      $dialog_button.append($dialog_button_div);
      $dialog_div.append($dialog_button);

      $dialog_copy_button.click(function () {
        var content = '';
        if (showParams.type == 'batch') {
          $.each(linkList, function (index, element) {
            if (element.downloadlink == 'error')
              return;
            if (index == linkList.length - 1)
              content = content + element.downloadlink;
            else
              content = content + element.downloadlink + '\n';
          });
        } else if (showParams.type == 'link') {
          $.each(linkList, function (index, element) {
            if (element.url == 'error')
              return;
            if (index == linkList.length - 1)
              content = content + element.url;
            else
              content = content + element.url + '\n';
          });
        }
        GM_setClipboard(content, 'text');
        alert('已将链接复制到剪贴板！');
      });

      $dialog_edit_button.click(function () {
        var $dialog_textarea = $('div.dialog-body textarea[name=dialog-textarea]', dialog);
        var $dialog_item = $('div.dialog-body div', dialog);
        $dialog_item.hide();
        $dialog_copy_button.hide();
        $dialog_edit_button.hide();
        $dialog_textarea.show();
        $dialog_radio_div.show();
        $dialog_exit_button.show();
      });

      $dialog_exit_button.click(function () {
        var $dialog_textarea = $('div.dialog-body textarea[name=dialog-textarea]', dialog);
        var $dialog_item = $('div.dialog-body div', dialog);
        $dialog_textarea.hide();
        $dialog_radio_div.hide();
        $dialog_item.show();
        $dialog_exit_button.hide();
        $dialog_copy_button.show();
        $dialog_edit_button.show();
      });

      $dialog_div.append($dialog_tip);
      $('body').append($dialog_div);
      $dialog_div.dialogDrag();
      $dialog_control.click(dialogControl);
      return $dialog_div;
    }

    function createShadow() {
      var $shadow = $('<div class="dialog-shadow" style="position: fixed; left: 0px; top: 0px; z-index: 50; background: rgb(0, 0, 0) none repeat scroll 0% 0%; opacity: 0.5; width: 100%; height: 100%; display: none;"></div>');
      $('body').append($shadow);
      return $shadow;
    }

    this.open = function (params) {
      $('body').on('click', '.GMlink', function (event) {
        event.preventDefault();
        var link = $(this)[0].innerText;
        console.log(link)
        GM_download({
          url: link,
          name: '非IDM下载请自己改后缀名.zip',
          headers: {
            "User-Agent": "netdisk;6.7.1.9;PC;PC-Windows;10.0.17763;WindowsBaiduYunGuanJia",
          },
          onprogress: function (e) {
            console.log(JSON.stringify(e))
          },
        });

        return false;
      });

      showParams = params;
      linkList = [];
      if (params.type == 'link' || params.type == 'GMlink') {
        linkList = params.list.urls;
        $('div.dialog-header h3 span.dialog-title', dialog).text(params.title + "：" + params.list.filename);
        $.each(params.list.urls, function (index, element) {
          if (params.type == 'GMlink') {
            var $div = $('<div><div style="width:30px;float:left">' + element.rank + ':</div><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><a class="GMlink" href="' + element.url + '">' + element.url + '</a></div></div>');
          } else {
            var $div = $('<div><div style="width:30px;float:left">' + element.rank + ':</div><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><a href="' + element.url + '">' + element.url + '</a></div></div>');
          }

          $('div.dialog-body', dialog).append($div);
        });
      }
      if (params.type == 'batch' || params.type == 'GMbatch') {
        linkList = params.list;
        $('div.dialog-header h3 span.dialog-title', dialog).text(params.title);
        if (params.showall) {
          $.each(params.list, function (index, element) {
            var $item_div = $('<div class="item-container" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"></div>');
            var $item_name = $('<div style="width:100px;float:left;overflow:hidden;text-overflow:ellipsis" title="' + element.filename + '">' + element.filename + '</div>');
            var $item_sep = $('<div style="width:12px;float:left"><span>：</span></div>');
            var $item_link_div = $('<div class="item-link" style="float:left;width:618px;"></div>');
            var $item_first = $('<div class="item-first" style="overflow:hidden;text-overflow:ellipsis"><a href="' + element.downloadlink + '">' + element.downloadlink + '</a></div>');
            $item_link_div.append($item_first);
            $.each(params.alllist[index].links, function (n, item) {
              if (element.downloadlink == item.url)
                return;
              if (params.type == 'GMbatch') {
                var $item = $('<div class="item-ex" style="display:none;overflow:hidden;text-overflow:ellipsis"><a class="GMlink" href="' + item.url + '">' + item.url + '</a></div>');
              } else {
                var $item = $('<div class="item-ex" style="display:none;overflow:hidden;text-overflow:ellipsis"><a href="' + item.url + '">' + item.url + '</a></div>');
              }

              $item_link_div.append($item);
            });
            var $item_ex = $('<div style="width:15px;float:left;cursor:pointer;text-align:center;font-size:16px"><span>+</span></div>');
            $item_div.append($item_name).append($item_sep).append($item_link_div).append($item_ex);
            $item_ex.click(function () {
              var $parent = $(this).parent();
              $parent.toggleClass('showall');
              if ($parent.hasClass('showall')) {
                $(this).text('-');
                $('div.item-link div.item-ex', $parent).show();
              } else {
                $(this).text('+');
                $('div.item-link div.item-ex', $parent).hide();
              }
            });
            $('div.dialog-body', dialog).append($item_div);
          });
        } else {
          $.each(params.list, function (index, element) {
            var $div = $('<div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><div style="width:100px;float:left;overflow:hidden;text-overflow:ellipsis" title="' + element.filename + '">' + element.filename + '</div><span>：</span><a href="' + element.downloadlink + '">' + element.downloadlink + '</a></div>');
            $('div.dialog-body', dialog).append($div);
          });
        }
      }
      if (params.type == 'shareLink') {
        linkList = params.list;
        $('div.dialog-header h3 span.dialog-title', dialog).text(params.title);
        $.each(params.list, function (index, element) {
          if (element.isdir == 1) return;
          var $div = $('<div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><div style="width:100px;float:left;overflow:hidden;text-overflow:ellipsis" title="' + element.server_filename + '">' + element.server_filename + '</div><span>：</span><a href="' + element.dlink + '">' + element.dlink + '</a></div>');
          $('div.dialog-body', dialog).append($div);
        });
      }

      if (params.tip) {
        $('div.dialog-tip p', dialog).html(params.tip);
      }

      if (params.showcopy) {
        $('div.dialog-button', dialog).show();
        $('div.dialog-button button#dialog-copy-button', dialog).show();
      }
      if (params.showedit) {
        $('div.dialog-button', dialog).show();
        $('div.dialog-button button#dialog-edit-button', dialog).show();
        var $dialog_textarea = $('<textarea name="dialog-textarea" style="display:none;resize:none;width:758px;height:300px;white-space:pre;word-wrap:normal;overflow-x:scroll"></textarea>');
        var content = '';
        if (showParams.type == 'batch') {
          $.each(linkList, function (index, element) {
            if (element.downloadlink == 'error')
              return;
            if (index == linkList.length - 1)
              content = content + element.downloadlink;
            else
              content = content + element.downloadlink + '\n';
          });
        } else if (showParams.type == 'link') {
          $.each(linkList, function (index, element) {
            if (element.url == 'error')
              return;
            if (index == linkList.length - 1)
              content = content + element.url;
            else
              content = content + element.url + '\n';
          });
        }
        $dialog_textarea.val(content);
        $('div.dialog-body', dialog).append($dialog_textarea);
      }

      shadow.show();
      dialog.show();
    };

    this.close = function () {
      dialogControl();
    };

    function dialogControl() {
      $('div.dialog-body', dialog).children().remove();
      $('div.dialog-header h3 span.dialog-title', dialog).text('');
      $('div.dialog-tip p', dialog).text('');
      $('div.dialog-button', dialog).hide();
      $('div.dialog-radio input[type=radio][name=showmode][value=multi]', dialog).prop('checked', true);
      $('div.dialog-radio', dialog).hide();
      $('div.dialog-button button#dialog-copy-button', dialog).hide();
      $('div.dialog-button button#dialog-edit-button', dialog).hide();
      $('div.dialog-button button#dialog-exit-button', dialog).hide();
      dialog.hide();
      shadow.hide();
    }

    dialog = createDialog();
    shadow = createShadow();
  }

  function VCodeDialog(refreshVCode, confirmClick) {
    var dialog, shadow;

    function createDialog() {
      var screenWidth = document.body.clientWidth;
      var dialogLeft = screenWidth > 520 ? (screenWidth - 520) / 2 : 0;
      var $dialog_div = $('<div class="dialog" id="dialog-vcode" style="width:520px;top:0px;bottom:auto;left:' + dialogLeft + 'px;right:auto;display:none;visibility:visible;z-index:52"></div>');
      var $dialog_header = $('<div class="dialog-header"><h3><span class="dialog-header-title"><em class="select-text">提示</em></span></h3></div>');
      var $dialog_control = $('<div class="dialog-control"><span class="dialog-icon dialog-close icon icon-close"><span class="sicon">x</span></span></div>');
      var $dialog_body = $('<div class="dialog-body"></div>');
      var $dialog_body_div = $('<div style="text-align:center;padding:22px"></div>');
      var $dialog_body_download_verify = $('<div class="download-verify" style="margin-top:10px;padding:0 28px;text-align:left;font-size:12px;"></div>');
      var $dialog_verify_body = $('<div class="verify-body">请输入验证码：</div>');
      var $dialog_input = $('<input id="dialog-input" type="text" style="padding:3px;width:85px;height:23px;border:1px solid #c6c6c6;background-color:white;vertical-align:middle;" class="input-code" maxlength="4">');
      var $dialog_img = $('<img id="dialog-img" class="img-code" style="margin-left:10px;vertical-align:middle;" alt="点击换一张" src="" width="100" height="30">');
      var $dialog_refresh = $('<a href="javascript:void(0)" style="text-decoration:underline;" class="underline">换一张</a>');
      var $dialog_err = $('<div id="dialog-err" style="padding-left:84px;height:18px;color:#d80000" class="verify-error"></div>');
      var $dialog_footer = $('<div class="dialog-footer g-clearfix"></div>');
      var $dialog_confirm_button = $('<a class="g-button g-button-blue" data-button-id="" data-button-index href="javascript:void(0)" style="padding-left:36px"><span class="g-button-right" style="padding-right:36px;"><span class="text" style="width:auto;">确定</span></span></a>');
      var $dialog_cancel_button = $('<a class="g-button" data-button-id="" data-button-index href="javascript:void(0);" style="padding-left: 36px;"><span class="g-button-right" style="padding-right: 36px;"><span class="text" style="width: auto;">取消</span></span></a>');

      $dialog_header.append($dialog_control);
      $dialog_verify_body.append($dialog_input).append($dialog_img).append($dialog_refresh);
      $dialog_body_download_verify.append($dialog_verify_body).append($dialog_err);
      $dialog_body_div.append($dialog_body_download_verify);
      $dialog_body.append($dialog_body_div);
      $dialog_footer.append($dialog_confirm_button).append($dialog_cancel_button);
      $dialog_div.append($dialog_header).append($dialog_body).append($dialog_footer);
      $('body').append($dialog_div);

      $dialog_div.dialogDrag();

      $dialog_control.click(dialogControl);
      $dialog_img.click(refreshVCode);
      $dialog_refresh.click(refreshVCode);
      $dialog_input.keypress(function (event) {
        if (event.which == 13)
          confirmClick();
      });
      $dialog_confirm_button.click(confirmClick);
      $dialog_cancel_button.click(dialogControl);
      $dialog_input.click(function () {
        $('#dialog-err').text('');
      });
      return $dialog_div;
    }

    this.open = function (vcode) {
      if (vcode)
        $('#dialog-img').attr('src', vcode.img);
      dialog.show();
      shadow.show();
    };
    this.close = function () {
      dialogControl();
    };
    dialog = createDialog();
    shadow = $('div.dialog-shadow');

    function dialogControl() {
      $('#dialog-img', dialog).attr('src', '');
      $('#dialog-err').text('');
      dialog.hide();
      shadow.hide();
    }
  }

  $.fn.dialogDrag = function () {
    var mouseInitX, mouseInitY, dialogInitX, dialogInitY;
    var screenWidth = document.body.clientWidth;
    var $parent = this;
    $('div.dialog-header', this).mousedown(function (event) {
      mouseInitX = parseInt(event.pageX);
      mouseInitY = parseInt(event.pageY);
      dialogInitX = parseInt($parent.css('left').replace('px', ''));
      dialogInitY = parseInt($parent.css('top').replace('px', ''));
      $(this).mousemove(function (event) {
        var tempX = dialogInitX + parseInt(event.pageX) - mouseInitX;
        var tempY = dialogInitY + parseInt(event.pageY) - mouseInitY;
        var width = parseInt($parent.css('width').replace('px', ''));
        tempX = tempX < 0 ? 0 : tempX > screenWidth - width ? screenWidth - width : tempX;
        tempY = tempY < 0 ? 0 : tempY;
        $parent.css('left', tempX + 'px').css('top', tempY + 'px');
      });
    });
    $('div.dialog-header', this).mouseup(function (event) {
      $(this).unbind('mousemove');
    });
  };

  (function () {
    var script = document.createElement("script");
    script.type = "text/javascript";
    script.src = "https://js.users.51.la/19988117.js";
    document.getElementsByTagName("head")[0].appendChild(script);
  })();

  $(function () {
    classMap['default-dom'] = ($('.icon-upload').parent().parent().parent().parent().parent().attr('class'));
    classMap['bar'] = ($('.icon-upload').parent().parent().parent().parent().attr('class'));

    switch (detectPage()) {
      case 'disk':
        var panHelper = new PanHelper();
        panHelper.init();
        return;
      case 'share':
      case 's':
        var panShareHelper = new PanShareHelper();
        panShareHelper.init();
        return;
      default:
        return;
    }
  });

})();